"""patch_thesis_with_results.py
================================
Take the JSON produced by run_full_pipeline.py and overwrite the
illustrative numbers in the thesis docx with the real ones.

Usage
-----
    $ python patch_thesis_with_results.py \\
          results/thesis_results.json \\
          Thesis_CNN_ViT_Hybrid.docx \\
          Thesis_CNN_ViT_Hybrid_REAL.docx

What gets patched
-----------------
* Table 3-2  (descriptive statistics of numeric features)
* Table 3-3  (Pearson correlation matrix)
* Table 4-2  (per-epoch training logs — selected epochs)
* Table 4-3  (final test-set classification metrics)
* Table 4-4  (per-class precision / recall / F1)
* Table 4-5  (comparison with baselines)
* Table 4-7  (inference latency)

The script identifies tables by their caption text in the docx
("Table 3-2  Descriptive statistics ..." etc.) so it doesn't
depend on the order of tables in the document.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn


# -----------------------------------------------------------------------------
# Helpers for finding tables by their caption
# -----------------------------------------------------------------------------
def find_table_by_caption(doc, caption_starts_with: str):
    """Return the first table whose IMMEDIATELY-PRECEDING paragraph
    starts with the given text.  Each caption in the thesis is the
    paragraph right above the table.
    """
    body = doc.element.body
    paras_and_tables = list(body)
    for i, el in enumerate(paras_and_tables):
        if el.tag != qn("w:tbl"):
            continue
        # Look back for the previous w:p with text
        for j in range(i - 1, -1, -1):
            prev = paras_and_tables[j]
            if prev.tag == qn("w:p"):
                text = "".join(t.text or "" for t in prev.iter(qn("w:t"))).strip()
                if not text:
                    continue
                if text.startswith(caption_starts_with):
                    # Match — find the corresponding python-docx Table object
                    for tbl in doc.tables:
                        if tbl._tbl is el:
                            return tbl
                # First non-empty preceding paragraph that doesn't match
                # — give up on this table
                break
    return None


def set_cell_text(cell, text: str, bold: bool = False, size: float = 9):
    """Replace cell content with a single run of the given text."""
    # Clear existing paragraphs
    for p in list(cell.paragraphs):
        p_elem = p._p
        p_elem.getparent().remove(p_elem)
    new_p = cell.add_paragraph()
    run = new_p.add_run(str(text))
    run.font.name = "Times New Roman"
    run.font.size = Pt(size)
    if bold:
        run.bold = True


def overwrite_table_rows(table, header: List[str], rows: List[List[Any]]):
    """Wipe the table body (keep header row 0) and rewrite all rows.
    The table is resized in place to len(rows)+1 rows."""
    # First, fix the header
    while len(table.rows[0].cells) > len(header):
        # python-docx doesn't expose remove easily; if too many cells we just
        # skip them.
        break

    for j, h in enumerate(header):
        if j < len(table.rows[0].cells):
            set_cell_text(table.rows[0].cells[j], h, bold=True, size=10)

    # Resize: add rows if needed
    while len(table.rows) < len(rows) + 1:
        table.add_row()

    # Optionally trim extra rows
    while len(table.rows) > len(rows) + 1:
        last_tr = table.rows[-1]._tr
        last_tr.getparent().remove(last_tr)

    # Fill body
    for ri, row_vals in enumerate(rows, start=1):
        for ci, v in enumerate(row_vals):
            if ci < len(table.rows[ri].cells):
                set_cell_text(table.rows[ri].cells[ci], v, size=9)


# -----------------------------------------------------------------------------
# Per-table patchers
# -----------------------------------------------------------------------------
def patch_table_3_2(doc, results):
    """Descriptive statistics of numeric features."""
    tbl = find_table_by_caption(doc, "Table 3-2")
    if tbl is None:
        print("  ! Table 3-2 not found"); return
    desc = results["dataset_stats"]["feature_describe"]
    feat_names = results["meta"]["feature_names"]
    rows = []
    for col in feat_names:
        d = desc[col]
        rows.append([
            col,
            f"{d['mean']:.3f}", f"{d['std']:.3f}", f"{d['min']:.3f}",
            f"{d['p25']:.3f}",  f"{d['p50']:.3f}", f"{d['p75']:.3f}",
            f"{d['max']:.3f}",
        ])
    overwrite_table_rows(tbl, ["Feature", "Mean", "Std", "Min", "25%",
                                "50%", "75%", "Max"], rows)
    print("  ✓ Table 3-2 patched")


def patch_table_3_3(doc, results):
    """Pearson correlation matrix."""
    tbl = find_table_by_caption(doc, "Table 3-3")
    if tbl is None:
        print("  ! Table 3-3 not found"); return
    corr = results["dataset_stats"]["correlation_matrix"]
    feat_names = results["meta"]["feature_names"]
    short = ["Price", "Stock Qty.", "Warranty", "Rating"]
    if len(short) != len(feat_names):
        short = feat_names
    rows = []
    for i, name in enumerate(short):
        row = [name]
        for j in range(len(short)):
            row.append(f"{corr[i][j]:.4f}")
        rows.append(row)
    overwrite_table_rows(tbl, [""] + short, rows)
    print("  ✓ Table 3-3 patched")


def patch_table_4_2(doc, results):
    """Per-epoch training logs (selected epochs)."""
    tbl = find_table_by_caption(doc, "Table 4-2")
    if tbl is None:
        print("  ! Table 4-2 not found"); return
    history = results["hybrid_cnn_vit"]["history"]
    n = len(history)
    if n == 0: return
    # Choose ~8 representative epochs: 1, 5, 10, 20, ..., last
    pick = sorted(set([1, max(1, n // 10), max(1, n // 5),
                        max(1, n // 2), max(1, 3 * n // 4),
                        max(1, n - 2), n]))
    pick = [p for p in pick if 1 <= p <= n]
    rows = []
    for p in pick:
        h = history[p - 1]
        rows.append([
            str(h["epoch"]),
            f"{h['train_loss']:.4f}",
            f"{h['train_acc']:.4f}",
            f"{h['val_loss']:.4f}",
            f"{h['val_acc']:.4f}",
            f"{h['lr']:.2e}",
            f"{h['time_s']:.1f}",
        ])
    overwrite_table_rows(tbl, ["Epoch", "Train Loss", "Train Acc",
                                "Val Loss", "Val Acc", "LR", "Time(s)"], rows)
    print("  ✓ Table 4-2 patched")


def patch_table_4_3(doc, results):
    """Final test-set classification metrics."""
    tbl = find_table_by_caption(doc, "Table 4-3")
    if tbl is None:
        print("  ! Table 4-3 not found"); return
    h = results["hybrid_cnn_vit"]
    history = h["history"]
    final_test_loss = history[-1]["val_loss"] if history else 0.0
    rows = [
        ["Test accuracy",         f"{h['accuracy']:.4f}"],
        ["Test loss (val proxy)", f"{final_test_loss:.4f}"],
        ["Macro F1",              f"{h['macro_f1']:.4f}"],
        ["Macro precision",       f"{h['macro_precision']:.4f}"],
        ["Macro recall",          f"{h['macro_recall']:.4f}"],
        ["Macro ROC-AUC (OvR)",   f"{h['macro_roc_auc']:.4f}"],
        ["ECE",                   f"{h.get('ece', 0):.4f}"],
        ["Best validation acc.",  f"{h['best_val_acc']:.4f}"],
        ["Total parameters",      f"{h['param_count']:,}"],
    ]
    overwrite_table_rows(tbl, ["Metric", "Value"], rows)
    print("  ✓ Table 4-3 patched")


def patch_table_4_4(doc, results):
    """Per-class precision / recall / F1."""
    tbl = find_table_by_caption(doc, "Table 4-4")
    if tbl is None:
        print("  ! Table 4-4 not found"); return
    rep = results["hybrid_cnn_vit"]["per_class_report"]
    class_names = results["meta"]["class_names"]
    rows = []
    for c in class_names:
        if c in rep:
            r = rep[c]
            rows.append([c,
                         f"{r['precision']:.3f}",
                         f"{r['recall']:.3f}",
                         f"{r['f1-score']:.3f}",
                         f"{int(r['support'])}"])
    if "macro avg" in rep:
        m = rep["macro avg"]
        rows.append(["Macro avg",
                     f"{m['precision']:.3f}",
                     f"{m['recall']:.3f}",
                     f"{m['f1-score']:.3f}",
                     f"{int(m['support'])}"])
    overwrite_table_rows(tbl, ["Class", "Precision", "Recall", "F1", "Support"], rows)
    print("  ✓ Table 4-4 patched")


def patch_table_4_5(doc, results):
    """Comparison with baselines."""
    tbl = find_table_by_caption(doc, "Table 4-5")
    if tbl is None:
        print("  ! Table 4-5 not found"); return
    bl = results.get("baselines", {})
    da = results.get("deep_ablations", {})
    h  = results["hybrid_cnn_vit"]

    def fmt(m):
        if not m: return ["-"] * 5
        return [f"{m['accuracy']:.4f}",
                f"{m['macro_f1']:.4f}",
                f"{m['macro_precision']:.4f}",
                f"{m['macro_recall']:.4f}",
                f"{m['macro_roc_auc']:.4f}"]

    rows = []
    if bl.get("random_forest"): rows.append(["Random Forest"] + fmt(bl["random_forest"]))
    if bl.get("mlp"):           rows.append(["MLP"]            + fmt(bl["mlp"]))
    if bl.get("xgboost"):       rows.append(["XGBoost"]        + fmt(bl["xgboost"]))
    if da.get("cnn_only"):      rows.append(["CNN-only"]       + fmt(da["cnn_only"]))
    if da.get("vit_only"):      rows.append(["ViT-only"]       + fmt(da["vit_only"]))
    rows.append(["Hybrid CNN-ViT (ours)"] + fmt(h))

    overwrite_table_rows(tbl, ["Model", "Acc.", "Macro F1",
                                "Macro Prec.", "Macro Rec.", "AUC"], rows)
    print("  ✓ Table 4-5 patched")


def patch_table_4_7(doc, results):
    """Inference latency."""
    tbl = find_table_by_caption(doc, "Table 4-7")
    if tbl is None:
        print("  ! Table 4-7 not found"); return
    cpu = results["latency"].get("cpu") or {}
    gpu = results["latency"].get("gpu") or {}

    def fmt_lat(d):
        if not d: return ["-"] * 5
        return [f"{d['mean_ms']:.2f}",
                f"{d['median_ms']:.2f}",
                f"{d['p95_ms']:.2f}",
                f"{d['p99_ms']:.2f}",
                f"{d['throughput_per_s']:.0f} rec/s"]

    rows = [["CPU"] + fmt_lat(cpu)]
    if gpu:
        rows.append(["GPU"] + fmt_lat(gpu))

    overwrite_table_rows(tbl, ["Device", "Mean (ms)", "Median (ms)",
                                "P95 (ms)", "P99 (ms)", "Throughput"], rows)
    print("  ✓ Table 4-7 patched")


def patch_table_4_8(doc, results):
    """Anomaly-detection performance."""
    tbl = find_table_by_caption(doc, "Table 4-8")
    if tbl is None:
        print("  ! Table 4-8 not found (skipped)"); return
    ad = results.get("anomaly_detection", {})
    cb = ad.get("confidence_based", {}) or {}
    iso = ad.get("isolation_forest", {}) or {}

    def fmt_cb():
        if not cb: return ["-"] * 5
        return [f"{cb.get('average_precision', 0):.3f}",
                f"{cb.get('roc_auc', 0):.3f}",
                f"{cb.get('precision', 0):.3f}",
                f"{cb.get('recall', 0):.3f}",
                f"{cb.get('f1', 0):.3f}"]

    def fmt_iso():
        if not iso: return ["-"] * 5
        return [f"{iso.get('iso_average_precision', 0):.3f}",
                f"{iso.get('iso_roc_auc', 0):.3f}",
                "—", "—", "—"]

    tau = cb.get('tau', 0.45)
    rows = [
        [f"Hybrid CNN-ViT confidence (τ={tau})"] + fmt_cb(),
        ["Isolation Forest baseline"] + fmt_iso(),
    ]
    overwrite_table_rows(tbl, ["Detector", "Avg. Precision", "ROC-AUC",
                                "Precision @ τ", "Recall @ τ", "F1 @ τ"], rows)
    print("  ✓ Table 4-8 patched")


def patch_table_4_9(doc, results):
    """Per-class most-frequent confusion partner."""
    tbl = find_table_by_caption(doc, "Table 4-9")
    if tbl is None:
        print("  ! Table 4-9 not found (skipped)"); return

    cm = results["hybrid_cnn_vit"].get("confusion_matrix", [])
    class_names = results["meta"]["class_names"]
    if not cm or not class_names: return

    import numpy as np
    cm_arr = np.array(cm)
    rows = []
    for i, cname in enumerate(class_names):
        row = cm_arr[i].copy()
        row[i] = -1  # ignore the diagonal
        if row.max() <= 0:
            partner = "—"; n_err = 0
        else:
            partner_idx = int(row.argmax())
            partner = class_names[partner_idx]
            n_err = int(row.max())
        rows.append([cname, partner, str(n_err)])

    overwrite_table_rows(tbl, ["True class", "Most frequent confusion partner",
                                "Errors of this kind"], rows)
    print("  ✓ Table 4-9 patched")


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("results_json", help="Path to thesis_results.json")
    parser.add_argument("input_docx",   help="Path to thesis docx (input)")
    parser.add_argument("output_docx",  help="Path to write patched docx")
    args = parser.parse_args()

    print(f"Loading results: {args.results_json}")
    with open(args.results_json) as f:
        results = json.load(f)

    print(f"Loading docx   : {args.input_docx}")
    doc = Document(args.input_docx)
    print(f"  {len(doc.tables)} tables, {len(doc.paragraphs)} paragraphs")

    print("\nPatching tables:")
    patch_table_3_2(doc, results)
    patch_table_3_3(doc, results)
    patch_table_4_2(doc, results)
    patch_table_4_3(doc, results)
    patch_table_4_4(doc, results)
    patch_table_4_5(doc, results)
    patch_table_4_7(doc, results)
    patch_table_4_8(doc, results)
    patch_table_4_9(doc, results)

    print(f"\nSaving to: {args.output_docx}")
    doc.save(args.output_docx)
    print("Done.")


if __name__ == "__main__":
    main()
