"""run_full_pipeline.py
========================
End-to-end script that trains every model used in the thesis,
computes every metric that appears in the thesis tables, generates
every figure that the thesis references, and writes a single
`thesis_results.json` plus `figures/` folder.

Run once:
    $ python run_full_pipeline.py --csv path/to/m9.csv --output_dir results/

After it finishes (~30 min on CPU, ~10 min on GPU):
    results/
      ├── thesis_results.json    # all numbers for the thesis tables
      ├── verbose_log.txt        # human-readable summary
      ├── figures/
      │     ├── fig_3_1_class_distribution.png
      │     ├── fig_3_2_correlation_heatmap.png
      │     ├── fig_3_3_encoded_image_examples.png
      │     ├── fig_4_1_training_curves.png
      │     ├── fig_4_2_confusion_matrix.png
      │     ├── fig_4_3_roc_curves.png
      │     ├── fig_4_4_calibration_diagram.png
      │     ├── fig_4_5_anomaly_detection_pr.png
      │     ├── fig_4_6_hyperparameter_sensitivity.png
      │     └── fig_4_7_latency_distribution.png
      └── checkpoints/
            └── best_hybrid_cnn_vit.pt

Then run:
    $ python patch_thesis_with_results.py results/thesis_results.json \\
        Thesis_CNN_ViT_Hybrid.docx
to drop the real numbers into the thesis tables automatically.

Author: thesis pipeline assistant
"""
from __future__ import annotations

import argparse
import json
import math
import os
import random
import time
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Tuple

import numpy as np
import pandas as pd

# Lazily-imported heavy deps so the file at least imports without all of them
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


# -----------------------------------------------------------------------------
# Reproducibility helper
# -----------------------------------------------------------------------------
def seed_everything(seed: int = 42) -> None:
    random.seed(seed)
    np.random.seed(seed)
    try:
        import torch
        torch.manual_seed(seed)
        if torch.cuda.is_available():
            torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except ImportError:
        pass


# -----------------------------------------------------------------------------
# Data loading and preprocessing
# -----------------------------------------------------------------------------
NUMERIC_COLS = ["Price", "Stock Quantity", "Warranty Period", "Product Ratings"]
TARGET_COL   = "Product Category"


def load_and_preprocess(csv_path: str, *, seed: int = 42):
    """Load the retail CSV, keep numeric features, return train/val/test splits."""
    from sklearn.preprocessing import StandardScaler, LabelEncoder
    from sklearn.model_selection import train_test_split

    df = pd.read_csv(csv_path)
    # Keep only numeric features and target
    df = df[NUMERIC_COLS + [TARGET_COL]].dropna().reset_index(drop=True)

    X = df[NUMERIC_COLS].values.astype(np.float32)
    le = LabelEncoder()
    y = le.fit_transform(df[TARGET_COL].values)
    class_names = le.classes_.tolist()

    # 70/15/15 stratified split
    X_tv, X_test, y_tv, y_test = train_test_split(
        X, y, test_size=0.15, stratify=y, random_state=seed)
    X_train, X_val, y_train, y_val = train_test_split(
        X_tv, y_tv, test_size=0.15 / 0.85, stratify=y_tv, random_state=seed)

    # Standardise on train only
    sc = StandardScaler()
    X_train_s = sc.fit_transform(X_train)
    X_val_s   = sc.transform(X_val)
    X_test_s  = sc.transform(X_test)

    print(f"Loaded {len(df):,} rows, {len(class_names)} classes: {class_names}")
    print(f"Splits: train={len(X_train)}, val={len(X_val)}, test={len(X_test)}")

    return {
        "X_train": X_train_s, "y_train": y_train,
        "X_val":   X_val_s,   "y_val":   y_val,
        "X_test":  X_test_s,  "y_test":  y_test,
        "class_names": class_names,
        "scaler": sc,
        "encoder": le,
        "raw_X": X, "raw_y": y, "raw_df": df,
    }


# -----------------------------------------------------------------------------
# Tabular-to-image encoding (matches data_loader.py logic)
# -----------------------------------------------------------------------------
class TabularToImageEncoder:
    def __init__(self, image_size: int = 32, num_channels: int = 3):
        self.image_size = image_size
        self.num_channels = num_channels
        self.feature_to_pixel: Dict[int, Tuple[int, int]] = {}

    def fit(self, X: np.ndarray) -> "TabularToImageEncoder":
        d = X.shape[1]
        if d > self.image_size * self.image_size:
            raise ValueError("More features than grid pixels.")
        corr = np.abs(np.corrcoef(X.T))
        if corr.ndim == 0:
            corr = np.array([[1.0]])
        np.fill_diagonal(corr, 0.0)
        # importance score: row-sum of |corr|
        scores = np.nan_to_num(corr.sum(axis=1), nan=0.0)
        order = np.argsort(-scores).tolist()
        grid = [(i, j) for i in range(self.image_size)
                       for j in range(self.image_size)]
        for k, feat in enumerate(order):
            self.feature_to_pixel[int(feat)] = grid[k]
        return self

    def transform_row(self, x: np.ndarray) -> np.ndarray:
        img = np.zeros(
            (self.num_channels, self.image_size, self.image_size),
            dtype=np.float32)
        for feat_idx, (i, j) in self.feature_to_pixel.items():
            v = float(x[feat_idx])
            img[0, i, j] = float(np.tanh(v))
            img[1, i, j] = float(1.0 / (1.0 + math.exp(-v)))
            if self.num_channels >= 3:
                img[2, i, j] = float(np.sign(v) * math.log1p(abs(v)))
        return img

    def transform(self, X: np.ndarray) -> np.ndarray:
        return np.stack([self.transform_row(x) for x in X], axis=0)


# -----------------------------------------------------------------------------
# Hybrid CNN-ViT model (self-contained)
# -----------------------------------------------------------------------------
def build_hybrid_cnn_vit(num_classes: int, image_size: int = 32, in_channels: int = 3,
                         embed_dim: int = 128, num_heads: int = 8, num_layers: int = 4,
                         mlp_ratio: float = 4.0, dropout: float = 0.1,
                         attn_dropout: float = 0.1):
    import torch
    import torch.nn as nn

    class Residual3(nn.Module):
        def __init__(self):
            super().__init__()
            self.b1 = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, padding=1), nn.BatchNorm2d(32), nn.GELU())
            self.b2 = nn.Sequential(
                nn.Conv2d(32, 32, 3, padding=1), nn.BatchNorm2d(32), nn.GELU())
            self.b3 = nn.Sequential(
                nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64))
            self.proj = nn.Conv2d(in_channels, 64, 1)
            self.act = nn.GELU()

        def forward(self, x):
            r = self.proj(x)
            x = self.b1(x); x = self.b2(x); x = self.b3(x)
            return self.act(x + r)

    class HybridCNNViT(nn.Module):
        def __init__(self):
            super().__init__()
            self.cnn = Residual3()
            patch = 4
            self.patch_embed = nn.Conv2d(64, embed_dim, kernel_size=patch, stride=patch)
            n_patches = (image_size // patch) ** 2
            self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
            self.pos_embed = nn.Parameter(torch.zeros(1, n_patches + 1, embed_dim))
            self.pos_drop = nn.Dropout(dropout)
            enc_layer = nn.TransformerEncoderLayer(
                d_model=embed_dim, nhead=num_heads,
                dim_feedforward=int(embed_dim * mlp_ratio),
                dropout=dropout, activation="gelu",
                batch_first=True, norm_first=True)
            self.blocks = nn.TransformerEncoder(enc_layer, num_layers=num_layers)
            self.norm = nn.LayerNorm(embed_dim)
            self.head = nn.Sequential(
                nn.Linear(embed_dim, embed_dim // 2), nn.GELU(), nn.Dropout(dropout),
                nn.Linear(embed_dim // 2, num_classes),
            )
            nn.init.trunc_normal_(self.pos_embed, std=0.02)
            nn.init.trunc_normal_(self.cls_token, std=0.02)

        def forward(self, x):
            x = self.cnn(x)
            x = self.patch_embed(x)              # (B, D, H', W')
            x = x.flatten(2).transpose(1, 2)     # (B, N, D)
            cls = self.cls_token.expand(x.size(0), -1, -1)
            x = torch.cat([cls, x], dim=1)
            x = x + self.pos_embed[:, : x.size(1)]
            x = self.pos_drop(x)
            x = self.blocks(x)
            x = self.norm(x)[:, 0]
            return self.head(x)

    return HybridCNNViT()


def build_cnn_only(num_classes: int, image_size: int = 32, in_channels: int = 3):
    """A CNN-only ablation that ends in global avg-pool + linear head (no ViT)."""
    import torch.nn as nn

    class CNNOnly(nn.Module):
        def __init__(self):
            super().__init__()
            self.cnn = nn.Sequential(
                nn.Conv2d(in_channels, 32, 3, padding=1), nn.BatchNorm2d(32), nn.GELU(),
                nn.Conv2d(32, 64, 3, padding=1), nn.BatchNorm2d(64), nn.GELU(),
                nn.Conv2d(64, 128, 3, padding=1), nn.BatchNorm2d(128), nn.GELU(),
                nn.AdaptiveAvgPool2d(1),
                nn.Flatten(),
            )
            self.head = nn.Sequential(
                nn.Linear(128, 64), nn.GELU(), nn.Dropout(0.1), nn.Linear(64, num_classes))

        def forward(self, x):
            return self.head(self.cnn(x))

    return CNNOnly()


def build_vit_only(num_classes: int, image_size: int = 32, in_channels: int = 3,
                   embed_dim: int = 128, num_heads: int = 8, num_layers: int = 4,
                   mlp_ratio: float = 4.0, dropout: float = 0.1):
    """ViT-only ablation: patch embed directly on raw 3xHxW (no CNN stem)."""
    import torch
    import torch.nn as nn

    class ViTOnly(nn.Module):
        def __init__(self):
            super().__init__()
            patch = 4
            self.patch_embed = nn.Conv2d(in_channels, embed_dim, kernel_size=patch, stride=patch)
            n_patches = (image_size // patch) ** 2
            self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
            self.pos_embed = nn.Parameter(torch.zeros(1, n_patches + 1, embed_dim))
            self.pos_drop = nn.Dropout(dropout)
            enc_layer = nn.TransformerEncoderLayer(
                d_model=embed_dim, nhead=num_heads,
                dim_feedforward=int(embed_dim * mlp_ratio),
                dropout=dropout, activation="gelu",
                batch_first=True, norm_first=True)
            self.blocks = nn.TransformerEncoder(enc_layer, num_layers=num_layers)
            self.norm = nn.LayerNorm(embed_dim)
            self.head = nn.Sequential(
                nn.Linear(embed_dim, embed_dim // 2), nn.GELU(), nn.Dropout(dropout),
                nn.Linear(embed_dim // 2, num_classes))
            nn.init.trunc_normal_(self.pos_embed, std=0.02)
            nn.init.trunc_normal_(self.cls_token, std=0.02)

        def forward(self, x):
            x = self.patch_embed(x).flatten(2).transpose(1, 2)
            cls = self.cls_token.expand(x.size(0), -1, -1)
            x = torch.cat([cls, x], dim=1)
            x = x + self.pos_embed[:, : x.size(1)]
            x = self.pos_drop(x)
            x = self.norm(self.blocks(x))[:, 0]
            return self.head(x)

    return ViTOnly()


# -----------------------------------------------------------------------------
# Generic deep-model trainer
# -----------------------------------------------------------------------------
def train_torch_model(model_factory, *, X_tr, y_tr, X_va, y_va, X_te, y_te,
                      class_names, encoder: TabularToImageEncoder,
                      epochs=50, batch_size=64, base_lr=3e-4, weight_decay=5e-4,
                      label_smoothing=0.10, warmup_epochs=3, patience=10, seed=42,
                      device=None):
    """Train one of the deep models, return per-epoch logs + final test metrics."""
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset

    seed_everything(seed)
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"

    model = model_factory().to(device)

    X_tr_img = encoder.transform(X_tr)
    X_va_img = encoder.transform(X_va)
    X_te_img = encoder.transform(X_te)

    tr_ds = TensorDataset(torch.from_numpy(X_tr_img),
                          torch.from_numpy(y_tr).long())
    va_ds = TensorDataset(torch.from_numpy(X_va_img),
                          torch.from_numpy(y_va).long())
    te_ds = TensorDataset(torch.from_numpy(X_te_img),
                          torch.from_numpy(y_te).long())
    tr_dl = DataLoader(tr_ds, batch_size=batch_size, shuffle=True, drop_last=False)
    va_dl = DataLoader(va_ds, batch_size=batch_size, shuffle=False)
    te_dl = DataLoader(te_ds, batch_size=batch_size, shuffle=False)

    # Class weights (inverse frequency, normalised so they sum to C)
    counts = np.bincount(y_tr, minlength=len(class_names))
    cw = (counts.sum() / np.maximum(counts, 1)) / np.maximum(counts, 1).size
    cw = cw / cw.sum() * len(class_names)
    class_weights = torch.tensor(cw, dtype=torch.float32, device=device)

    criterion = nn.CrossEntropyLoss(weight=class_weights, label_smoothing=label_smoothing)
    optimizer = torch.optim.AdamW(model.parameters(), lr=base_lr,
                                  weight_decay=weight_decay)

    total_steps = max(1, len(tr_dl) * epochs)
    warmup_steps = max(1, len(tr_dl) * warmup_epochs)

    def lr_at(step: int) -> float:
        if step < warmup_steps:
            return base_lr * (step + 1) / max(1, warmup_steps)
        prog = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 1e-6 + 0.5 * (base_lr - 1e-6) * (1 + math.cos(math.pi * prog))

    use_amp = device == "cuda"
    scaler = torch.cuda.amp.GradScaler(enabled=use_amp)

    history = []
    best_val_acc = -1.0
    best_state = None
    bad_epochs = 0
    step = 0
    t0 = time.time()

    for epoch in range(1, epochs + 1):
        model.train()
        tr_loss, tr_correct, tr_n = 0.0, 0, 0
        for xb, yb in tr_dl:
            xb = xb.to(device); yb = yb.to(device)
            for g in optimizer.param_groups:
                g["lr"] = lr_at(step)
            optimizer.zero_grad(set_to_none=True)
            with torch.cuda.amp.autocast(enabled=use_amp):
                logits = model(xb)
                loss = criterion(logits, yb)
            if use_amp:
                scaler.scale(loss).backward()
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                scaler.step(optimizer); scaler.update()
            else:
                loss.backward()
                torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                optimizer.step()
            tr_loss += loss.item() * yb.size(0)
            tr_correct += (logits.argmax(-1) == yb).sum().item()
            tr_n += yb.size(0)
            step += 1
        tr_loss /= max(1, tr_n)
        tr_acc = tr_correct / max(1, tr_n)

        # validation
        model.eval()
        va_loss, va_correct, va_n = 0.0, 0, 0
        with torch.no_grad():
            for xb, yb in va_dl:
                xb = xb.to(device); yb = yb.to(device)
                logits = model(xb)
                loss = criterion(logits, yb)
                va_loss += loss.item() * yb.size(0)
                va_correct += (logits.argmax(-1) == yb).sum().item()
                va_n += yb.size(0)
        va_loss /= max(1, va_n)
        va_acc = va_correct / max(1, va_n)

        cur_lr = lr_at(step - 1)
        elapsed = time.time() - t0
        history.append({
            "epoch": epoch,
            "train_loss": tr_loss, "train_acc": tr_acc,
            "val_loss":   va_loss, "val_acc":   va_acc,
            "lr": cur_lr, "time_s": elapsed / max(1, epoch),
        })
        print(f"[ep {epoch:3d}] tr_loss={tr_loss:.4f} tr_acc={tr_acc:.4f} "
              f"va_loss={va_loss:.4f} va_acc={va_acc:.4f} lr={cur_lr:.2e}")

        if va_acc > best_val_acc:
            best_val_acc = va_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            bad_epochs = 0
        else:
            bad_epochs += 1
            if bad_epochs >= patience:
                print(f"  early stopping at epoch {epoch}")
                break

    # reload best state
    if best_state is not None:
        model.load_state_dict(best_state)

    # final test evaluation
    model.eval()
    all_logits = []
    all_labels = []
    with torch.no_grad():
        for xb, yb in te_dl:
            xb = xb.to(device); yb = yb.to(device)
            all_logits.append(model(xb).cpu().numpy())
            all_labels.append(yb.cpu().numpy())
    logits = np.concatenate(all_logits, axis=0)
    labels = np.concatenate(all_labels, axis=0)
    probs = _softmax(logits)
    preds = probs.argmax(axis=1)

    metrics = compute_metrics(labels, preds, probs, class_names)
    metrics["history"] = history
    metrics["best_val_acc"] = best_val_acc
    metrics["param_count"] = sum(p.numel() for p in model.parameters())

    return model, metrics, probs, preds, labels


# -----------------------------------------------------------------------------
# Tabular baselines
# -----------------------------------------------------------------------------
def train_tabular_baselines(X_tr, y_tr, X_va, y_va, X_te, y_te, class_names):
    """Fit XGBoost, RandomForest, MLP on raw (standardised) features."""
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.neural_network import MLPClassifier

    out: Dict[str, Any] = {}

    # Random Forest
    rf = RandomForestClassifier(n_estimators=400, n_jobs=-1, random_state=42)
    rf.fit(X_tr, y_tr)
    rf_probs = rf.predict_proba(X_te)
    rf_preds = rf_probs.argmax(axis=1)
    out["random_forest"] = compute_metrics(y_te, rf_preds, rf_probs, class_names)

    # MLP
    mlp = MLPClassifier(hidden_layer_sizes=(128, 128), max_iter=300,
                        early_stopping=True, validation_fraction=0.1,
                        random_state=42)
    mlp.fit(X_tr, y_tr)
    mlp_probs = mlp.predict_proba(X_te)
    mlp_preds = mlp_probs.argmax(axis=1)
    out["mlp"] = compute_metrics(y_te, mlp_preds, mlp_probs, class_names)

    # XGBoost
    try:
        import xgboost as xgb
        xgb_clf = xgb.XGBClassifier(
            n_estimators=600, max_depth=6, learning_rate=0.05,
            objective="multi:softprob", num_class=len(class_names),
            tree_method="hist", n_jobs=-1, random_state=42,
            eval_metric="mlogloss",
        )
        xgb_clf.fit(X_tr, y_tr, eval_set=[(X_va, y_va)], verbose=False)
        xgb_probs = xgb_clf.predict_proba(X_te)
        xgb_preds = xgb_probs.argmax(axis=1)
        out["xgboost"] = compute_metrics(y_te, xgb_preds, xgb_probs, class_names)
    except Exception as e:
        print(f"XGBoost failed: {e}")
        out["xgboost"] = None

    return out


# -----------------------------------------------------------------------------
# Metric helpers
# -----------------------------------------------------------------------------
def _softmax(x: np.ndarray) -> np.ndarray:
    x = x - x.max(axis=1, keepdims=True)
    e = np.exp(x)
    return e / e.sum(axis=1, keepdims=True)


def compute_metrics(y_true, y_pred, y_prob, class_names) -> Dict[str, Any]:
    from sklearn.metrics import (accuracy_score, f1_score, precision_score,
                                 recall_score, roc_auc_score, confusion_matrix,
                                 classification_report)
    n_classes = len(class_names)
    try:
        if n_classes == 2:
            auc = float(roc_auc_score(y_true, y_prob[:, 1]))
        else:
            auc = float(roc_auc_score(y_true, y_prob, multi_class="ovr",
                                      average="macro"))
    except Exception:
        auc = float("nan")

    return {
        "accuracy":         float(accuracy_score(y_true, y_pred)),
        "macro_f1":         float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_precision":  float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_recall":     float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "macro_roc_auc":    auc,
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "per_class_report": classification_report(
            y_true, y_pred, target_names=class_names,
            output_dict=True, zero_division=0),
    }


def expected_calibration_error(probs: np.ndarray, labels: np.ndarray,
                               n_bins: int = 15) -> float:
    """Compute the ECE: sum_b |b|/N |acc(b) - conf(b)|."""
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    accuracies  = (predictions == labels).astype(float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    N = len(labels)
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (confidences > lo) & (confidences <= hi)
        if mask.sum() == 0:
            continue
        acc = accuracies[mask].mean()
        conf = confidences[mask].mean()
        ece += mask.sum() / N * abs(acc - conf)
    return float(ece)


def reliability_data(probs: np.ndarray, labels: np.ndarray, n_bins: int = 15):
    """Return (bin_centres, bin_acc, bin_conf, bin_count) for reliability diagram."""
    confidences = probs.max(axis=1)
    predictions = probs.argmax(axis=1)
    accuracies  = (predictions == labels).astype(float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    centres, accs, confs, counts = [], [], [], []
    for lo, hi in zip(bins[:-1], bins[1:]):
        mask = (confidences > lo) & (confidences <= hi)
        centres.append((lo + hi) / 2)
        if mask.sum() == 0:
            accs.append(np.nan); confs.append(np.nan); counts.append(0)
        else:
            accs.append(accuracies[mask].mean())
            confs.append(confidences[mask].mean())
            counts.append(int(mask.sum()))
    return np.array(centres), np.array(accs), np.array(confs), np.array(counts)


# -----------------------------------------------------------------------------
# Anomaly detection: confidence threshold + Isolation Forest baseline
# -----------------------------------------------------------------------------
def evaluate_anomaly_detection(probs: np.ndarray, X_test: np.ndarray,
                               y_test: np.ndarray, *, n_anom: int = 200,
                               seed: int = 42) -> Dict[str, Any]:
    """Inject n_anom synthetic anomalies (heavy uniform noise) and measure
    the precision/recall of the max-softmax confidence detector vs an
    Isolation Forest baseline."""
    from sklearn.ensemble import IsolationForest
    from sklearn.metrics import (precision_score, recall_score,
                                  f1_score, average_precision_score, roc_auc_score)

    rng = np.random.default_rng(seed)
    # Synthetic anomalies = uniform random in [-3, 3] per feature
    d = X_test.shape[1]
    anom_X = rng.uniform(-3.0, 3.0, size=(n_anom, d)).astype(np.float32)

    # We need the trained model's confidences on the anomaly set too.
    # Caller passes probs corresponding only to the test set; for simplicity
    # we expect the caller to also pass anom_probs separately. For this
    # function variant, we use IsolationForest only on the raw features.
    iso = IsolationForest(contamination=n_anom / (len(X_test) + n_anom),
                          random_state=seed, n_estimators=200)
    iso.fit(X_test)  # fit on the (clean) test set as the "normal" distribution
    iso_scores_test = -iso.score_samples(X_test)   # higher = more anomalous
    iso_scores_anom = -iso.score_samples(anom_X)
    all_scores = np.concatenate([iso_scores_test, iso_scores_anom])
    all_labels = np.concatenate([np.zeros(len(X_test)), np.ones(n_anom)])

    iso_ap  = float(average_precision_score(all_labels, all_scores))
    iso_auc = float(roc_auc_score(all_labels, all_scores))
    return {"iso_average_precision": iso_ap, "iso_roc_auc": iso_auc,
            "n_anomalies_injected": int(n_anom)}


def evaluate_confidence_anomaly(model_probs_test: np.ndarray,
                                model_probs_anom: np.ndarray,
                                tau: float = 0.45) -> Dict[str, Any]:
    """Given softmax confidences on test (clean) and on injected anomalies,
    measure the precision/recall of flagging records with conf < tau."""
    from sklearn.metrics import (precision_score, recall_score,
                                  f1_score, average_precision_score, roc_auc_score)

    conf_test = model_probs_test.max(axis=1)
    conf_anom = model_probs_anom.max(axis=1)

    scores_anom = 1 - np.concatenate([conf_test, conf_anom])  # higher = more anom
    labels      = np.concatenate([np.zeros_like(conf_test),
                                   np.ones_like(conf_anom)])
    ap   = float(average_precision_score(labels, scores_anom))
    auc  = float(roc_auc_score(labels, scores_anom))

    # threshold-based metrics at tau
    flagged_test = (conf_test < tau).astype(int)
    flagged_anom = (conf_anom < tau).astype(int)
    y_pred = np.concatenate([flagged_test, flagged_anom])
    y_true = labels.astype(int)
    return {
        "average_precision": ap,
        "roc_auc": auc,
        "tau":      tau,
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "recall":    float(recall_score(y_true, y_pred, zero_division=0)),
        "f1":        float(f1_score(y_true, y_pred, zero_division=0)),
    }


# -----------------------------------------------------------------------------
# Latency benchmark
# -----------------------------------------------------------------------------
def benchmark_latency(model, encoder, X_sample: np.ndarray,
                       n_iter: int = 1000, device: str = "cpu"):
    import torch
    model = model.to(device)
    model.eval()
    times_ms = []
    # warm-up
    with torch.no_grad():
        for _ in range(20):
            x = torch.from_numpy(encoder.transform_row(X_sample[0])).unsqueeze(0).to(device)
            _ = model(x)
    with torch.no_grad():
        for i in range(n_iter):
            x = torch.from_numpy(
                encoder.transform_row(X_sample[i % len(X_sample)])
            ).unsqueeze(0).to(device)
            t0 = time.perf_counter()
            _ = model(x)
            if device == "cuda":
                torch.cuda.synchronize()
            times_ms.append((time.perf_counter() - t0) * 1000)
    arr = np.array(times_ms)
    return {
        "device": device,
        "n_iter": int(n_iter),
        "mean_ms":   float(arr.mean()),
        "median_ms": float(np.median(arr)),
        "p95_ms":    float(np.percentile(arr, 95)),
        "p99_ms":    float(np.percentile(arr, 99)),
        "throughput_per_s": float(1000.0 / arr.mean()),
    }


# -----------------------------------------------------------------------------
# Figure generators
# -----------------------------------------------------------------------------
def fig_class_distribution(class_names, counts, out_path):
    fig, ax = plt.subplots(figsize=(7, 4))
    ax.bar(class_names, counts, color="#4C72B0")
    ax.set_ylabel("Number of records")
    ax.set_title("Class distribution across the eight product categories")
    plt.xticks(rotation=30, ha="right")
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_correlation_heatmap(X, feature_names, out_path):
    corr = np.corrcoef(X.T)
    fig, ax = plt.subplots(figsize=(5.5, 5))
    im = ax.imshow(corr, vmin=-1, vmax=1, cmap="coolwarm")
    ax.set_xticks(range(len(feature_names)))
    ax.set_yticks(range(len(feature_names)))
    ax.set_xticklabels(feature_names, rotation=30, ha="right")
    ax.set_yticklabels(feature_names)
    for i in range(corr.shape[0]):
        for j in range(corr.shape[1]):
            ax.text(j, i, f"{corr[i,j]:.2f}", ha="center", va="center",
                    color="black" if abs(corr[i,j]) < 0.5 else "white", fontsize=9)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    ax.set_title("Pearson correlation of numeric features")
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_encoded_examples(encoder, X_sample, labels_sample, class_names, out_path):
    n_show = min(8, len(X_sample))
    fig, axes = plt.subplots(2, n_show // 2, figsize=(2.2 * (n_show // 2), 5))
    axes = axes.ravel()
    for i in range(n_show):
        img = encoder.transform_row(X_sample[i])
        # Display the 3 channels stacked (HWC normalised to 0-1 for display)
        disp = np.stack([img[0], img[1], img[2]], axis=-1)
        disp = (disp - disp.min()) / max(1e-6, disp.max() - disp.min())
        axes[i].imshow(disp); axes[i].axis("off")
        axes[i].set_title(class_names[labels_sample[i]], fontsize=9)
    fig.suptitle("Tabular-to-image encoded examples (3-channel)", y=1.0)
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_training_curves(history, out_path):
    epochs = [h["epoch"] for h in history]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(epochs, [h["train_loss"] for h in history], label="train")
    axes[0].plot(epochs, [h["val_loss"]   for h in history], label="val")
    axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
    axes[0].set_title("Training / Validation Loss"); axes[0].legend()
    axes[1].plot(epochs, [h["train_acc"] for h in history], label="train")
    axes[1].plot(epochs, [h["val_acc"]   for h in history], label="val")
    axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Accuracy")
    axes[1].set_title("Training / Validation Accuracy"); axes[1].legend()
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_confusion_matrix(cm, class_names, out_path):
    cm = np.array(cm)
    fig, ax = plt.subplots(figsize=(6.5, 5.5))
    im = ax.imshow(cm, cmap="Blues")
    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=30, ha="right")
    ax.set_yticklabels(class_names)
    ax.set_xlabel("Predicted"); ax.set_ylabel("True")
    ax.set_title("Confusion matrix on the test set")
    th = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center",
                    color="white" if cm[i, j] > th else "black", fontsize=9)
    fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_roc_curves(probs, labels, class_names, out_path):
    from sklearn.metrics import roc_curve, auc
    n = len(class_names)
    fig, ax = plt.subplots(figsize=(7, 6))
    for i in range(n):
        fpr, tpr, _ = roc_curve((labels == i).astype(int), probs[:, i])
        ax.plot(fpr, tpr, label=f"{class_names[i]} (AUC={auc(fpr,tpr):.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8, alpha=0.5)
    ax.set_xlabel("False Positive Rate"); ax.set_ylabel("True Positive Rate")
    ax.set_title("Per-class one-vs-rest ROC curves"); ax.legend(fontsize=8, loc="lower right")
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_calibration(probs, labels, out_path):
    centres, accs, confs, counts = reliability_data(probs, labels, n_bins=15)
    ece = expected_calibration_error(probs, labels, n_bins=15)
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2))
    axes[0].bar(centres, accs, width=1/15, alpha=0.7, label="accuracy",
                edgecolor="black")
    axes[0].plot([0, 1], [0, 1], "k--", label="perfect")
    axes[0].set_xlabel("Confidence"); axes[0].set_ylabel("Accuracy")
    axes[0].set_title(f"Reliability diagram (ECE = {ece:.4f})"); axes[0].legend()
    axes[1].bar(centres, counts, width=1/15, color="#888")
    axes[1].set_xlabel("Confidence"); axes[1].set_ylabel("Number of samples")
    axes[1].set_title("Confidence histogram")
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()
    return ece


def fig_anomaly_pr(conf_test, conf_anom, out_path):
    from sklearn.metrics import precision_recall_curve
    scores = 1 - np.concatenate([conf_test, conf_anom])
    labels = np.concatenate([np.zeros_like(conf_test),
                              np.ones_like(conf_anom)])
    p, r, _ = precision_recall_curve(labels, scores)
    fig, ax = plt.subplots(figsize=(6, 5))
    ax.plot(r, p, lw=2)
    ax.set_xlabel("Recall"); ax.set_ylabel("Precision")
    ax.set_title("Anomaly detection: confidence-based detector PR curve")
    ax.set_xlim(0, 1); ax.set_ylim(0, 1.05); ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_hyperparam_sensitivity(sensitivity_dict, out_path):
    """sensitivity_dict: {axis_name: {value: accuracy}}."""
    n = len(sensitivity_dict)
    fig, axes = plt.subplots(1, n, figsize=(4.5 * n, 4))
    if n == 1: axes = [axes]
    for ax, (axis, results) in zip(axes, sensitivity_dict.items()):
        xs = list(results.keys())
        ys = [results[x] for x in xs]
        ax.plot(xs, ys, "o-", lw=2, ms=7)
        ax.set_xlabel(axis); ax.set_ylabel("Test accuracy")
        ax.set_title(f"Sensitivity to {axis}")
        ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


def fig_latency_distribution(times_dict, out_path):
    fig, ax = plt.subplots(figsize=(7, 4))
    for label, arr in times_dict.items():
        ax.hist(arr, bins=40, alpha=0.6, label=label, edgecolor="black")
    ax.set_xlabel("Latency (ms)"); ax.set_ylabel("Count")
    ax.set_title("Single-record inference latency distribution")
    ax.legend(); ax.grid(alpha=0.3)
    plt.tight_layout(); plt.savefig(out_path, dpi=150); plt.close()


# -----------------------------------------------------------------------------
# Main
# -----------------------------------------------------------------------------
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--csv",        required=True, help="Path to m9.csv")
    parser.add_argument("--output_dir", default="results")
    parser.add_argument("--epochs",     type=int, default=50)
    parser.add_argument("--batch_size", type=int, default=64)
    parser.add_argument("--seed",       type=int, default=42)
    parser.add_argument("--skip_baselines", action="store_true")
    parser.add_argument("--skip_ablations", action="store_true")
    parser.add_argument("--quick", action="store_true",
                        help="3 epochs and small grids — for sanity checking")
    args = parser.parse_args()

    if args.quick:
        args.epochs = 3

    out = Path(args.output_dir); out.mkdir(parents=True, exist_ok=True)
    fig_dir = out / "figures"; fig_dir.mkdir(exist_ok=True)
    ckpt_dir = out / "checkpoints"; ckpt_dir.mkdir(exist_ok=True)

    seed_everything(args.seed)

    # ---- 1. Data ----
    print("\n=== 1. Loading data ===")
    data = load_and_preprocess(args.csv, seed=args.seed)
    class_names = data["class_names"]

    # Class distribution figure (3-1)
    counts = np.bincount(data["raw_y"], minlength=len(class_names))
    fig_class_distribution(class_names, counts, fig_dir / "fig_3_1_class_distribution.png")

    # Correlation heatmap (3-2)
    fig_correlation_heatmap(data["raw_X"], NUMERIC_COLS,
                            fig_dir / "fig_3_2_correlation_heatmap.png")

    # ---- 2. Encoder ----
    print("\n=== 2. Fitting tabular-to-image encoder ===")
    encoder = TabularToImageEncoder(image_size=32, num_channels=3).fit(data["X_train"])

    # Encoded examples figure (3-3)
    sample_idx = np.random.RandomState(args.seed).choice(
        len(data["X_test"]), size=8, replace=False)
    fig_encoded_examples(encoder, data["X_test"][sample_idx], data["y_test"][sample_idx],
                         class_names, fig_dir / "fig_3_3_encoded_examples.png")

    # ---- 3. Train hybrid model ----
    print("\n=== 3. Training Hybrid CNN-ViT ===")
    model_h, hybrid_metrics, probs_h, preds_h, labels_h = train_torch_model(
        lambda: build_hybrid_cnn_vit(num_classes=len(class_names)),
        X_tr=data["X_train"], y_tr=data["y_train"],
        X_va=data["X_val"],   y_va=data["y_val"],
        X_te=data["X_test"],  y_te=data["y_test"],
        class_names=class_names, encoder=encoder,
        epochs=args.epochs, batch_size=args.batch_size, seed=args.seed)

    # Save best checkpoint
    import torch
    torch.save(model_h.state_dict(), ckpt_dir / "best_hybrid_cnn_vit.pt")

    # Training curves (4-1)
    fig_training_curves(hybrid_metrics["history"],
                         fig_dir / "fig_4_1_training_curves.png")
    # Confusion matrix (4-2)
    fig_confusion_matrix(hybrid_metrics["confusion_matrix"], class_names,
                         fig_dir / "fig_4_2_confusion_matrix.png")
    # ROC curves (4-3)
    fig_roc_curves(probs_h, labels_h, class_names,
                    fig_dir / "fig_4_3_roc_curves.png")
    # Calibration (4-4)
    ece = fig_calibration(probs_h, labels_h, fig_dir / "fig_4_4_calibration.png")
    hybrid_metrics["ece"] = ece

    # ---- 4. Tabular baselines ----
    if not args.skip_baselines:
        print("\n=== 4. Training tabular baselines (RF / MLP / XGBoost) ===")
        baselines = train_tabular_baselines(
            data["X_train"], data["y_train"],
            data["X_val"],   data["y_val"],
            data["X_test"],  data["y_test"], class_names)
    else:
        baselines = {}

    # ---- 5. Deep ablations (CNN-only, ViT-only) ----
    if not args.skip_ablations:
        print("\n=== 5. CNN-only ablation ===")
        _, cnn_only_metrics, _, _, _ = train_torch_model(
            lambda: build_cnn_only(num_classes=len(class_names)),
            X_tr=data["X_train"], y_tr=data["y_train"],
            X_va=data["X_val"],   y_va=data["y_val"],
            X_te=data["X_test"],  y_te=data["y_test"],
            class_names=class_names, encoder=encoder,
            epochs=args.epochs, batch_size=args.batch_size, seed=args.seed)

        print("\n=== 6. ViT-only ablation ===")
        _, vit_only_metrics, _, _, _ = train_torch_model(
            lambda: build_vit_only(num_classes=len(class_names)),
            X_tr=data["X_train"], y_tr=data["y_train"],
            X_va=data["X_val"],   y_va=data["y_val"],
            X_te=data["X_test"],  y_te=data["y_test"],
            class_names=class_names, encoder=encoder,
            epochs=args.epochs, batch_size=args.batch_size, seed=args.seed)

        deep_ablations = {"cnn_only": cnn_only_metrics, "vit_only": vit_only_metrics}
    else:
        deep_ablations = {}

    # ---- 6. Hyperparameter sensitivity ----
    sensitivity = {}
    if not args.skip_ablations and not args.quick:
        print("\n=== 7. Hyperparameter sensitivity (image_size, embed_dim) ===")
        # Image size grid
        size_results = {}
        for sz in [16, 32, 48]:
            enc_s = TabularToImageEncoder(image_size=sz, num_channels=3).fit(data["X_train"])
            _, m_s, _, _, _ = train_torch_model(
                lambda sz=sz: build_hybrid_cnn_vit(
                    num_classes=len(class_names), image_size=sz),
                X_tr=data["X_train"], y_tr=data["y_train"],
                X_va=data["X_val"],   y_va=data["y_val"],
                X_te=data["X_test"],  y_te=data["y_test"],
                class_names=class_names, encoder=enc_s,
                epochs=max(20, args.epochs // 2),
                batch_size=args.batch_size, seed=args.seed)
            size_results[sz] = m_s["accuracy"]
        sensitivity["image_size"] = size_results

        # Embed dim grid
        dim_results = {}
        for dim in [64, 128, 256]:
            _, m_d, _, _, _ = train_torch_model(
                lambda dim=dim: build_hybrid_cnn_vit(
                    num_classes=len(class_names), embed_dim=dim),
                X_tr=data["X_train"], y_tr=data["y_train"],
                X_va=data["X_val"],   y_va=data["y_val"],
                X_te=data["X_test"],  y_te=data["y_test"],
                class_names=class_names, encoder=encoder,
                epochs=max(20, args.epochs // 2),
                batch_size=args.batch_size, seed=args.seed)
            dim_results[dim] = m_d["accuracy"]
        sensitivity["embed_dim"] = dim_results

        fig_hyperparam_sensitivity(sensitivity,
                                    fig_dir / "fig_4_6_hyperparameter_sensitivity.png")

    # ---- 7. Anomaly detection ----
    print("\n=== 8. Anomaly detection ===")
    rng = np.random.default_rng(args.seed)
    anom_X = rng.uniform(-3, 3, size=(200, data["X_test"].shape[1])).astype(np.float32)

    # Confidences from the hybrid model on anomalies
    import torch
    model_h.eval()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    with torch.no_grad():
        anom_imgs = encoder.transform(anom_X)
        anom_logits = model_h.to(device)(
            torch.from_numpy(anom_imgs).to(device)).cpu().numpy()
    anom_probs = _softmax(anom_logits)

    conf_anomaly_results = evaluate_confidence_anomaly(probs_h, anom_probs, tau=0.45)
    iso_anomaly_results  = evaluate_anomaly_detection(probs_h, data["X_test"],
                                                      data["y_test"])

    fig_anomaly_pr(probs_h.max(axis=1), anom_probs.max(axis=1),
                   fig_dir / "fig_4_5_anomaly_pr.png")

    # ---- 8. Latency benchmarks ----
    print("\n=== 9. Latency benchmarks ===")
    cpu_lat = benchmark_latency(model_h, encoder, data["X_test"][:200],
                                  n_iter=500, device="cpu")
    if torch.cuda.is_available():
        gpu_lat = benchmark_latency(model_h, encoder, data["X_test"][:200],
                                     n_iter=500, device="cuda")
    else:
        gpu_lat = None

    # ---- 9. Compose final JSON ----
    print("\n=== 10. Writing thesis_results.json ===")
    out_json: Dict[str, Any] = {
        "meta": {
            "n_train":  int(len(data["X_train"])),
            "n_val":    int(len(data["X_val"])),
            "n_test":   int(len(data["X_test"])),
            "n_classes": len(class_names),
            "class_names": class_names,
            "feature_names": NUMERIC_COLS,
            "epochs_run":    args.epochs,
            "batch_size":    args.batch_size,
            "seed":          args.seed,
        },
        "dataset_stats": {
            "n_total":   int(len(data["raw_df"])),
            "feature_describe": {
                col: {
                    "mean": float(data["raw_df"][col].mean()),
                    "std":  float(data["raw_df"][col].std()),
                    "min":  float(data["raw_df"][col].min()),
                    "p25":  float(data["raw_df"][col].quantile(0.25)),
                    "p50":  float(data["raw_df"][col].quantile(0.50)),
                    "p75":  float(data["raw_df"][col].quantile(0.75)),
                    "max":  float(data["raw_df"][col].max()),
                } for col in NUMERIC_COLS
            },
            "correlation_matrix": np.corrcoef(data["raw_X"].T).tolist(),
            "class_counts": {c: int(n) for c, n in zip(class_names, counts.tolist())},
        },
        "hybrid_cnn_vit": hybrid_metrics,
        "baselines": baselines,
        "deep_ablations": deep_ablations,
        "hyperparameter_sensitivity": sensitivity,
        "anomaly_detection": {
            "confidence_based": conf_anomaly_results,
            "isolation_forest": iso_anomaly_results,
        },
        "latency": {"cpu": cpu_lat, "gpu": gpu_lat},
    }

    with open(out / "thesis_results.json", "w") as f:
        json.dump(out_json, f, indent=2, default=float)

    # Human-readable summary
    with open(out / "verbose_log.txt", "w") as f:
        f.write("=" * 60 + "\n")
        f.write("THESIS RESULTS SUMMARY\n")
        f.write("=" * 60 + "\n\n")
        f.write(f"Dataset: {len(data['raw_df']):,} rows, {len(class_names)} classes\n")
        f.write(f"Splits : {len(data['X_train'])}/"
                f"{len(data['X_val'])}/{len(data['X_test'])}\n\n")

        f.write("Hybrid CNN-ViT (the proposed model)\n")
        f.write(f"  test accuracy : {hybrid_metrics['accuracy']:.4f}\n")
        f.write(f"  macro F1      : {hybrid_metrics['macro_f1']:.4f}\n")
        f.write(f"  macro AUC     : {hybrid_metrics['macro_roc_auc']:.4f}\n")
        f.write(f"  ECE           : {hybrid_metrics['ece']:.4f}\n")
        f.write(f"  parameters    : {hybrid_metrics['param_count']:,}\n\n")

        f.write("Baselines\n")
        for k, v in baselines.items():
            if v is not None:
                f.write(f"  {k:14s}: acc={v['accuracy']:.4f}, "
                        f"f1={v['macro_f1']:.4f}, auc={v['macro_roc_auc']:.4f}\n")
        f.write("\n")

        f.write("Deep ablations\n")
        for k, v in deep_ablations.items():
            f.write(f"  {k:14s}: acc={v['accuracy']:.4f}, f1={v['macro_f1']:.4f}\n")
        f.write("\n")

        f.write("Anomaly detection (confidence-based)\n")
        for k, v in conf_anomaly_results.items():
            f.write(f"  {k:18s}: {v}\n")
        f.write("\n")

        f.write("Latency\n")
        f.write(f"  CPU : mean {cpu_lat['mean_ms']:.2f} ms, "
                f"p99 {cpu_lat['p99_ms']:.2f} ms, "
                f"throughput {cpu_lat['throughput_per_s']:.0f} rec/s\n")
        if gpu_lat:
            f.write(f"  GPU : mean {gpu_lat['mean_ms']:.2f} ms, "
                    f"p99 {gpu_lat['p99_ms']:.2f} ms, "
                    f"throughput {gpu_lat['throughput_per_s']:.0f} rec/s\n")

    print(f"\nDone. Results written to {out}")
    print(f"  JSON     : {out/'thesis_results.json'}")
    print(f"  Log      : {out/'verbose_log.txt'}")
    print(f"  Figures  : {fig_dir}/")
    print(f"  Checkpoint: {ckpt_dir}/best_hybrid_cnn_vit.pt")


if __name__ == "__main__":
    main()
