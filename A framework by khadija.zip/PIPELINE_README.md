# Generating Real Numbers for the Thesis

This directory contains everything needed to replace the **illustrative
target numbers** in the thesis with **real numbers from actual training
runs**. Two scripts do all the work.

## Workflow at a glance

```
m9.csv  ──►  run_full_pipeline.py  ──►  results/thesis_results.json
                                          + figures/*.png
                                          + checkpoints/best_hybrid_cnn_vit.pt

Thesis_CNN_ViT_Hybrid.docx  +  thesis_results.json  ──►  patch_thesis_with_results.py  ──►  Thesis_CNN_ViT_Hybrid_REAL.docx
```

## Step 1 — Train all models

```bash
# Install requirements
pip install -r requirements.txt

# Run the full pipeline (~30 min CPU, ~10 min GPU)
python run_full_pipeline.py --csv path/to/m9.csv --output_dir results

# OR for a quick sanity check (3 epochs, no ablations)
python run_full_pipeline.py --csv path/to/m9.csv --output_dir results --quick --skip_ablations
```

This produces:

```
results/
├── thesis_results.json         <-- numbers for every table in the thesis
├── verbose_log.txt             <-- human-readable summary
├── figures/
│   ├── fig_3_1_class_distribution.png
│   ├── fig_3_2_correlation_heatmap.png
│   ├── fig_3_3_encoded_examples.png
│   ├── fig_4_1_training_curves.png
│   ├── fig_4_2_confusion_matrix.png
│   ├── fig_4_3_roc_curves.png
│   ├── fig_4_4_calibration.png
│   ├── fig_4_5_anomaly_pr.png
│   ├── fig_4_6_hyperparameter_sensitivity.png
│   └── fig_4_7_latency_distribution.png  (if multiple devices)
└── checkpoints/
    └── best_hybrid_cnn_vit.pt
```

## Step 2 — Patch the thesis with the real numbers

```bash
python patch_thesis_with_results.py \
    results/thesis_results.json \
    Thesis_CNN_ViT_Hybrid.docx \
    Thesis_CNN_ViT_Hybrid_REAL.docx
```

The patcher locates each table by its **caption** (e.g. `"Table 4-3"`)
and rewrites every cell with the real values.  The patched tables are:

| Table | Content |
|-------|---------|
| 3-2 | Descriptive statistics of numeric features |
| 3-3 | Pearson correlation matrix |
| 4-2 | Per-epoch training logs |
| 4-3 | Final test-set classification metrics (acc, F1, AUC, ECE, params) |
| 4-4 | Per-class precision / recall / F1 |
| 4-5 | Comparison with baselines (RF, MLP, XGBoost, CNN-only, ViT-only, Hybrid) |
| 4-7 | Inference latency (CPU & GPU) |
| 4-8 | Anomaly-detection performance |
| 4-9 | Most-frequent confusion partner per class |

## Step 3 — Insert the figures into the thesis

The thesis currently shows **figure placeholders** like:

```
[ FIGURE 4.2: Confusion matrix on the held-out test set (counts). ]
```

After running Step 1, replace each placeholder by inserting the
corresponding PNG from `results/figures/` (in Word: `Insert > Picture`).
The mapping is:

| Placeholder | PNG file |
|-------------|----------|
| Figure 1.1  | `fig_1_1_workflow.png` (you create this manually — block diagram) |
| Figure 3.1  | `fig_3_1_class_distribution.png` |
| Figure 3.2  | `fig_3_2_correlation_heatmap.png` |
| Figure 3.3  | `fig_3_3_encoded_examples.png` |
| Figure 3.4  | `fig_3_4_architecture.png` (you create this manually — block diagram) |
| Figure 4.1  | `fig_4_1_training_curves.png` |
| Figure 4.2  | `fig_4_2_confusion_matrix.png` |
| Figure 4.3  | `fig_4_3_roc_curves.png` |
| Figure 4.4  | `fig_4_4_calibration.png` |
| Figure 4.5  | `fig_4_5_anomaly_pr.png` |
| Figure 4.6  | `fig_4_6_hyperparameter_sensitivity.png` |
| Figure 4.7  | `fig_4_7_latency_distribution.png` |

## Important notes on the prose

The patcher only modifies **tables**. The surrounding prose still
contains specific numbers that I picked as plausible targets (e.g.
"94.7% accuracy", "44% relative error reduction", "below 12 ms").
After patching, **read through the prose in Sections 4.7, 4.10, 4.11,
4.12, 4.14** and update those numbers manually to reflect what you
actually measured. A diff of the verbose_log.txt against the
illustrative numbers will tell you exactly what to change.

The English and Chinese abstracts also quote these numbers (94.7%,
0.943, 0.987, 12 ms) — update those too.

## Skipping parts of the pipeline

```bash
--skip_baselines       # don't train RF / MLP / XGBoost
--skip_ablations       # don't train CNN-only, ViT-only, sensitivity sweep
--quick                # 3 epochs (sanity check)
--epochs N             # change number of epochs
--batch_size N         # change batch size
--seed N               # change random seed (default 42)
```

## What you must do manually after patching

1. **Update prose numbers** that appear inline in Sections 4.7, 4.10,
   4.11, 4.12, 4.14 to match your real numbers.
2. **Update the abstracts** (Chinese and English) with the real
   headline numbers.
3. **Insert figures** as described above.
4. **Replace the three fabricated references** noted in
   `REFERENCE_VERIFICATION_REPORT.md` ([6], [34], [35]).
5. **Refresh the Table of Contents** in Word: References → Table of
   Contents → Automatic Table 1.
6. **Replace the `[Supervisor Name]` and `[Student ID]` placeholders**
   on the cover pages.
