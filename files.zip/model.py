"""
model.py
==========
Hybrid CNN–Vision Transformer (ViT) architecture for retail
product classification on tabular-to-image encoded inputs.

Pipeline
--------
    Image (B, C, H, W)
        |
        v
    +------------------------+
    | CNN Stem (Conv-Bn-ReLU)|     local-feature extractor
    +------------------------+
        |
        v
    +------------------------+
    | Patch Embedding        |     flattens into token sequence
    +------------------------+
        |
        v
    +------------------------+
    | + CLS token, + PosEmb  |
    +------------------------+
        |
        v
    +------------------------+
    | Transformer Encoder    |     global self-attention
    | (L layers, H heads)    |
    +------------------------+
        |
        v
    +------------------------+
    | MLP Classification Head|
    +------------------------+
        |
        v
        Logits (B, num_classes)

Author : Khadija Elkattany
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple

import math
import torch
import torch.nn as nn
import torch.nn.functional as F


# ---------------------------------------------------------------------------
# Hyper-parameter container
# ---------------------------------------------------------------------------
@dataclass
class ModelConfig:
    image_size: int = 32
    in_channels: int = 3
    num_classes: int = 5
    cnn_out_channels: int = 64
    patch_size: int = 4               # divides image_size after CNN
    embed_dim: int = 128
    num_heads: int = 8
    num_transformer_layers: int = 4
    mlp_ratio: float = 4.0
    dropout: float = 0.1
    attention_dropout: float = 0.1


# ---------------------------------------------------------------------------
# CNN Stem
# ---------------------------------------------------------------------------
class CNNStem(nn.Module):
    """
    Three-block convolutional stem.  Extracts hierarchical local
    features and produces a feature map suitable for patchifying.

    Output spatial resolution is unchanged (no down-sampling) so that
    the patch embedding controls token count predictably.
    """

    def __init__(self, in_channels: int, out_channels: int):
        super().__init__()
        mid = out_channels // 2
        self.block1 = nn.Sequential(
            nn.Conv2d(in_channels, mid, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid),
            nn.GELU(),
        )
        self.block2 = nn.Sequential(
            nn.Conv2d(mid, mid, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(mid),
            nn.GELU(),
        )
        self.block3 = nn.Sequential(
            nn.Conv2d(mid, out_channels, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.GELU(),
        )
        # Residual projection
        self.proj = nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        identity = self.proj(x)
        x = self.block1(x)
        x = self.block2(x)
        x = self.block3(x)
        return F.gelu(x + identity)


# ---------------------------------------------------------------------------
# Patch Embedding
# ---------------------------------------------------------------------------
class PatchEmbedding(nn.Module):
    """Splits a feature map into non-overlapping patches and projects
    each patch into an `embed_dim`-vector token."""

    def __init__(
        self,
        feature_map_channels: int,
        patch_size: int,
        embed_dim: int,
    ):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(
            feature_map_channels,
            embed_dim,
            kernel_size=patch_size,
            stride=patch_size,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # x: (B, C, H, W) -> (B, embed_dim, H/p, W/p) -> (B, N, embed_dim)
        x = self.proj(x)
        b, e, h, w = x.shape
        x = x.flatten(2).transpose(1, 2)
        return x


# ---------------------------------------------------------------------------
# Multi-Head Self-Attention
# ---------------------------------------------------------------------------
class MultiHeadSelfAttention(nn.Module):
    def __init__(
        self,
        dim: int,
        num_heads: int,
        attention_dropout: float = 0.0,
        proj_dropout: float = 0.0,
    ):
        super().__init__()
        assert dim % num_heads == 0, "dim must be divisible by num_heads"
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.scale = self.head_dim ** -0.5

        self.qkv = nn.Linear(dim, dim * 3, bias=True)
        self.attn_drop = nn.Dropout(attention_dropout)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, n, d = x.shape
        qkv = self.qkv(x).reshape(b, n, 3, self.num_heads, self.head_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # (3, B, H, N, d_h)
        q, k, v = qkv.unbind(0)

        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        out = (attn @ v).transpose(1, 2).reshape(b, n, d)
        out = self.proj(out)
        out = self.proj_drop(out)
        return out


# ---------------------------------------------------------------------------
# Transformer Encoder Block (Pre-Norm)
# ---------------------------------------------------------------------------
class TransformerBlock(nn.Module):
    def __init__(
        self,
        dim: int,
        num_heads: int,
        mlp_ratio: float,
        dropout: float,
        attention_dropout: float,
    ):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = MultiHeadSelfAttention(
            dim, num_heads,
            attention_dropout=attention_dropout,
            proj_dropout=dropout,
        )
        self.norm2 = nn.LayerNorm(dim)
        hidden = int(dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, dim),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


# ---------------------------------------------------------------------------
# Hybrid CNN-ViT Model
# ---------------------------------------------------------------------------
class HybridCNNViT(nn.Module):
    """
    Hybrid CNN–Vision Transformer network for retail product
    classification.  The CNN stem extracts dense local features;
    the transformer encoder models long-range dependencies between
    spatial regions; a CLS token aggregates the global representation
    for classification.
    """

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.cfg = cfg

        # 1. CNN feature extractor
        self.cnn = CNNStem(cfg.in_channels, cfg.cnn_out_channels)

        # 2. Patch embedding
        if cfg.image_size % cfg.patch_size != 0:
            raise ValueError(
                "image_size must be divisible by patch_size"
            )
        num_patches = (cfg.image_size // cfg.patch_size) ** 2
        self.patch_embed = PatchEmbedding(
            cfg.cnn_out_channels, cfg.patch_size, cfg.embed_dim
        )

        # 3. CLS token + positional embedding
        self.cls_token = nn.Parameter(torch.zeros(1, 1, cfg.embed_dim))
        self.pos_embed = nn.Parameter(
            torch.zeros(1, num_patches + 1, cfg.embed_dim)
        )
        self.pos_drop = nn.Dropout(cfg.dropout)

        # 4. Transformer encoder
        self.blocks = nn.ModuleList([
            TransformerBlock(
                dim=cfg.embed_dim,
                num_heads=cfg.num_heads,
                mlp_ratio=cfg.mlp_ratio,
                dropout=cfg.dropout,
                attention_dropout=cfg.attention_dropout,
            )
            for _ in range(cfg.num_transformer_layers)
        ])

        # 5. Classification head
        self.norm = nn.LayerNorm(cfg.embed_dim)
        self.head = nn.Sequential(
            nn.Linear(cfg.embed_dim, cfg.embed_dim // 2),
            nn.GELU(),
            nn.Dropout(cfg.dropout),
            nn.Linear(cfg.embed_dim // 2, cfg.num_classes),
        )

        self._init_weights()

    # ------------------------------------------------------------------
    def _init_weights(self) -> None:
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.LayerNorm):
                nn.init.zeros_(m.bias)
                nn.init.ones_(m.weight)

    # ------------------------------------------------------------------
    def forward_features(self, x: torch.Tensor) -> torch.Tensor:
        x = self.cnn(x)                               # (B, C', H, W)
        x = self.patch_embed(x)                       # (B, N, D)
        b, n, _ = x.shape
        cls = self.cls_token.expand(b, -1, -1)        # (B, 1, D)
        x = torch.cat([cls, x], dim=1)                # (B, N+1, D)
        x = x + self.pos_embed[:, : n + 1]
        x = self.pos_drop(x)
        for blk in self.blocks:
            x = blk(x)
        x = self.norm(x)
        return x[:, 0]                                # CLS token

    # ------------------------------------------------------------------
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feats = self.forward_features(x)
        return self.head(feats)

    # ------------------------------------------------------------------
    @torch.no_grad()
    def parameter_count(self) -> Tuple[int, int]:
        total = sum(p.numel() for p in self.parameters())
        trainable = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return total, trainable


# ---------------------------------------------------------------------------
# Convenience constructors
# ---------------------------------------------------------------------------
def build_model(num_classes: int, image_size: int = 32) -> HybridCNNViT:
    cfg = ModelConfig(
        image_size=image_size,
        in_channels=3,
        num_classes=num_classes,
        cnn_out_channels=64,
        patch_size=4,
        embed_dim=128,
        num_heads=8,
        num_transformer_layers=4,
    )
    return HybridCNNViT(cfg)


# ---------------------------------------------------------------------------
# Smoke test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    model = build_model(num_classes=5, image_size=32)
    x = torch.randn(2, 3, 32, 32)
    y = model(x)
    total, trainable = model.parameter_count()
    print(f"Output shape    : {y.shape}")
    print(f"Total params    : {total:,}")
    print(f"Trainable params: {trainable:,}")
