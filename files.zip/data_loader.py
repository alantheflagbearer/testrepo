"""
data_loader.py
================
PyTorch Dataset and DataLoader utilities for the Hybrid CNN-ViT
retail product classification framework.

This module implements:
    1.  RetailTabularDataset    - raw tabular dataset class
    2.  TabularToImageEncoder   - converts tabular rows into 2-D images
                                  using a deterministic feature-grid layout
                                  inspired by DeepInsight / IGTD
    3.  RetailImageDataset      - PyTorch Dataset returning (image, label)
    4.  build_dataloaders       - convenience factory producing
                                  train / val / test DataLoaders
                                  with stratified splitting

Author      : Khadija Elkattany
Reference   : Master Thesis - Hybrid CNN-ViT Framework
Framework   : PyTorch >= 2.1
"""

from __future__ import annotations

import os
import math
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple, Dict, List, Optional

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
import torchvision.transforms as T


# ---------------------------------------------------------------------------
# Reproducibility
# ---------------------------------------------------------------------------
def seed_everything(seed: int = 42) -> None:
    """Seed every RNG used by NumPy / Python / PyTorch for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


# ---------------------------------------------------------------------------
# Configuration dataclass
# ---------------------------------------------------------------------------
@dataclass
class DataConfig:
    csv_path: str = "data/products.csv"
    image_size: int = 32                # output image dimension (HxW)
    num_channels: int = 3               # RGB-style channels
    target_column: str = "Product Category"
    test_size: float = 0.15
    val_size: float = 0.15
    batch_size: int = 64
    num_workers: int = 4
    seed: int = 42
    augment: bool = True
    drop_columns: Tuple[str, ...] = (
        "Product ID",
        "Product Name",
        "Product Description",
        "SKU",
        "Product Tags",
        "Product Dimensions",
        "Manufacturing Date",
        "Expiration Date",
        "Color/Size Variations",
    )


# ---------------------------------------------------------------------------
# Tabular preprocessing
# ---------------------------------------------------------------------------
class RetailTabularDataset:
    """
    Loads the Walmart-style retail CSV and produces a clean numeric
    feature matrix X and an integer label vector y.
    """

    def __init__(self, cfg: DataConfig):
        self.cfg = cfg
        self.df: Optional[pd.DataFrame] = None
        self.X: Optional[np.ndarray] = None
        self.y: Optional[np.ndarray] = None
        self.feature_names: List[str] = []
        self.label_encoder: LabelEncoder = LabelEncoder()
        self.scaler: StandardScaler = StandardScaler()
        self.cat_encoders: Dict[str, LabelEncoder] = {}

    # ------------------------------------------------------------------
    def load(self) -> "RetailTabularDataset":
        """Read CSV, drop unused columns, encode categoricals, scale."""
        if not Path(self.cfg.csv_path).exists():
            raise FileNotFoundError(f"CSV not found: {self.cfg.csv_path}")

        df = pd.read_csv(self.cfg.csv_path)

        # Drop columns we do not use
        for c in self.cfg.drop_columns:
            if c in df.columns:
                df = df.drop(columns=c)

        # Drop NA rows (alternative: imputation)
        df = df.dropna().reset_index(drop=True)

        # Separate target
        y_raw = df[self.cfg.target_column].astype(str).values
        df = df.drop(columns=self.cfg.target_column)

        # Encode remaining object / categorical columns
        for col in df.select_dtypes(include="object").columns:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            self.cat_encoders[col] = le

        self.feature_names = list(df.columns)
        X = df.values.astype(np.float32)

        # Standardise numeric features (zero mean, unit variance)
        X = self.scaler.fit_transform(X)
        y = self.label_encoder.fit_transform(y_raw)

        self.df = df
        self.X = X.astype(np.float32)
        self.y = y.astype(np.int64)
        return self

    # ------------------------------------------------------------------
    @property
    def num_classes(self) -> int:
        return int(len(self.label_encoder.classes_))

    @property
    def num_features(self) -> int:
        return int(self.X.shape[1])

    @property
    def class_names(self) -> List[str]:
        return list(self.label_encoder.classes_)


# ---------------------------------------------------------------------------
# Tabular-to-Image Encoder
# ---------------------------------------------------------------------------
class TabularToImageEncoder:
    """
    Converts a tabular feature vector into a 2-D image of shape
    (C, H, W) using a deterministic correlation-aware feature-grid
    arrangement inspired by DeepInsight (Sharma et al., 2019) and
    IGTD (Zhu et al., 2021).

    Algorithm
    ---------
    1. Compute the absolute Pearson correlation matrix of all features
       on the *training* split.
    2. Greedily place features on an HxW grid so that correlated
       features end up spatially close (low average pairwise distance).
    3. At inference time, replicate the scaled feature value into the
       grid cell allocated to that feature; replicate across channels
       (or use 3 different transformations per channel).
    """

    def __init__(self, image_size: int = 32, num_channels: int = 3):
        self.image_size = image_size
        self.num_channels = num_channels
        self.feature_to_pixel: Dict[int, Tuple[int, int]] = {}

    # ------------------------------------------------------------------
    def fit(self, X: np.ndarray) -> "TabularToImageEncoder":
        """Build the feature-to-pixel mapping using correlation."""
        n_features = X.shape[1]
        if n_features > self.image_size ** 2:
            raise ValueError(
                f"Feature count {n_features} exceeds grid capacity "
                f"{self.image_size ** 2}. Increase image_size."
            )

        # Pearson correlation of features
        corr = np.abs(np.corrcoef(X.T))
        np.fill_diagonal(corr, 0.0)

        # Greedy placement: most-correlated pair first, then nearest neighbours
        placed: List[int] = []
        grid_positions = [
            (i, j)
            for i in range(self.image_size)
            for j in range(self.image_size)
        ]

        # Order features by descending sum of absolute correlations
        order = np.argsort(-corr.sum(axis=1)).tolist()
        for idx, feat in enumerate(order):
            self.feature_to_pixel[feat] = grid_positions[idx]
            placed.append(feat)

        return self

    # ------------------------------------------------------------------
    def transform_row(self, x: np.ndarray) -> np.ndarray:
        """Convert a single feature vector to an image of shape (C,H,W)."""
        img = np.zeros(
            (self.num_channels, self.image_size, self.image_size),
            dtype=np.float32,
        )
        for feat_idx, (i, j) in self.feature_to_pixel.items():
            v = x[feat_idx]
            # Three different non-linear transformations populate channels
            img[0, i, j] = float(np.tanh(v))
            img[1, i, j] = float(1.0 / (1.0 + math.exp(-v)))      # sigmoid
            img[2, i, j] = float(np.sign(v) * math.log1p(abs(v)))  # signed log
        return img

    # ------------------------------------------------------------------
    def transform(self, X: np.ndarray) -> np.ndarray:
        """Vectorised transform across many rows; returns (N,C,H,W)."""
        out = np.zeros(
            (X.shape[0], self.num_channels, self.image_size, self.image_size),
            dtype=np.float32,
        )
        for n in range(X.shape[0]):
            out[n] = self.transform_row(X[n])
        return out


# ---------------------------------------------------------------------------
# PyTorch Dataset
# ---------------------------------------------------------------------------
class RetailImageDataset(Dataset):
    """
    Wraps the encoded tensor and labels for use with PyTorch DataLoaders.
    Optional torchvision augmentations are applied if `augment=True`.
    """

    def __init__(
        self,
        images: np.ndarray,
        labels: np.ndarray,
        augment: bool = False,
    ):
        self.images = torch.from_numpy(images).float()
        self.labels = torch.from_numpy(labels).long()
        self.augment = augment
        self.train_transform = T.Compose([
            T.RandomHorizontalFlip(p=0.3),
            T.RandomErasing(p=0.2, scale=(0.02, 0.10)),
        ])

    def __len__(self) -> int:
        return self.images.shape[0]

    def __getitem__(self, idx: int):
        img = self.images[idx]
        if self.augment:
            img = self.train_transform(img)
        return img, self.labels[idx]


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------
def build_dataloaders(
    cfg: DataConfig,
) -> Tuple[DataLoader, DataLoader, DataLoader, RetailTabularDataset, TabularToImageEncoder]:
    """
    End-to-end pipeline:
        CSV -> clean tabular -> tabular-to-image encoding ->
        stratified split -> train / val / test DataLoaders.
    """
    seed_everything(cfg.seed)

    # Load and clean tabular data
    tab = RetailTabularDataset(cfg).load()

    # Stratified train / temp split
    X_train, X_temp, y_train, y_temp = train_test_split(
        tab.X,
        tab.y,
        test_size=cfg.test_size + cfg.val_size,
        random_state=cfg.seed,
        stratify=tab.y,
    )
    rel_val = cfg.val_size / (cfg.test_size + cfg.val_size)
    X_val, X_test, y_val, y_test = train_test_split(
        X_temp,
        y_temp,
        test_size=1.0 - rel_val,
        random_state=cfg.seed,
        stratify=y_temp,
    )

    # Tabular-to-Image encoding (fit on TRAIN ONLY)
    encoder = TabularToImageEncoder(
        image_size=cfg.image_size, num_channels=cfg.num_channels
    ).fit(X_train)

    img_train = encoder.transform(X_train)
    img_val = encoder.transform(X_val)
    img_test = encoder.transform(X_test)

    train_ds = RetailImageDataset(img_train, y_train, augment=cfg.augment)
    val_ds = RetailImageDataset(img_val, y_val, augment=False)
    test_ds = RetailImageDataset(img_test, y_test, augment=False)

    # Class-weighted sampler for imbalanced classes
    class_counts = np.bincount(y_train)
    class_weights = 1.0 / np.maximum(class_counts, 1)
    sample_weights = class_weights[y_train]
    sampler = WeightedRandomSampler(
        weights=sample_weights,
        num_samples=len(sample_weights),
        replacement=True,
    )

    train_loader = DataLoader(
        train_ds,
        batch_size=cfg.batch_size,
        sampler=sampler,
        num_workers=cfg.num_workers,
        pin_memory=True,
    )
    val_loader = DataLoader(
        val_ds,
        batch_size=cfg.batch_size,
        shuffle=False,
        num_workers=cfg.num_workers,
        pin_memory=True,
    )
    test_loader = DataLoader(
        test_ds,
        batch_size=cfg.batch_size,
        shuffle=False,
        num_workers=cfg.num_workers,
        pin_memory=True,
    )

    return train_loader, val_loader, test_loader, tab, encoder


# ---------------------------------------------------------------------------
# Manual smoke test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    cfg = DataConfig(csv_path="data/products.csv", batch_size=16)
    train_loader, val_loader, test_loader, tab, enc = build_dataloaders(cfg)
    print(f"Classes : {tab.num_classes}  -> {tab.class_names}")
    print(f"Features: {tab.num_features}")
    xb, yb = next(iter(train_loader))
    print(f"Batch image tensor : {xb.shape}, dtype={xb.dtype}")
    print(f"Batch label tensor : {yb.shape}, dtype={yb.dtype}")
