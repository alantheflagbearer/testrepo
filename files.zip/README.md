# Hybrid CNN-ViT Framework for Real-Time Retail Product Classification

This repository accompanies the master thesis  
**"A Hybrid CNN–Vision-Transformer Framework with Tabular-to-Image Encoding for Real-Time Retail Product Classification and Anomaly Detection."**

## 1. Folder Structure

```
code/
├── data_loader.py        # tabular -> image encoding + DataLoader factory
├── model.py              # CNN backbone + ViT encoder + classifier head
├── train.py              # full training / validation / test pipeline
├── kafka_producer.py     # streams records to Kafka (Module 1)
├── kafka_consumer.py     # consumes records, runs CNN-ViT inference
├── dashboard.py          # Streamlit dashboard for KPIs
├── tabular_baselines.py  # XGBoost / Random-Forest baselines
├── requirements.txt
└── README.md
```

## 2. Environment

```bash
conda create -n cnnvit python=3.10 -y
conda activate cnnvit
pip install -r requirements.txt
```

GPU users: install the PyTorch build that matches your CUDA toolkit
from <https://pytorch.org/get-started/locally>.

## 3. Dataset

Place `products.csv` (10,000 rows, 14 columns) inside `data/`.

The CSV must contain at least these fields:

| Column            | Type  | Notes                  |
|-------------------|-------|------------------------|
| Product Category  | str   | classification target  |
| Price             | float |                        |
| Stock Quantity    | int   |                        |
| Warranty Period   | int   | months                 |
| Product Ratings   | float | 0 – 5                  |

## 4. Training

```bash
python train.py \
    --csv data/products.csv \
    --target "Product Category" \
    --epochs 50 \
    --batch_size 64 \
    --lr 3e-4 \
    --output_dir runs/cnn_vit
```

Outputs:
* `runs/cnn_vit/best.pt`           – best checkpoint  
* `runs/cnn_vit/history.json`      – per-epoch loss/accuracy  
* `runs/cnn_vit/test_metrics.json` – final classification metrics  

## 5. Real-Time Pipeline

In three terminals:

```bash
# 1) Kafka (default ports)
docker compose up kafka zookeeper

# 2) Producer  - streams new product rows
python kafka_producer.py

# 3) Consumer  - inference with the trained CNN-ViT
python kafka_consumer.py --ckpt runs/cnn_vit/best.pt
```

## 6. Dashboard

```bash
streamlit run dashboard.py
```

## 7. Citation

If you use this work, please cite:

```
Elkattany, K. (2026). A Hybrid CNN–Vision-Transformer Framework
with Tabular-to-Image Encoding for Real-Time Retail Product
Classification and Anomaly Detection.  Master Thesis,
Hubei University of Automotive Technology.
```

## 8. License

MIT.
