"""
kafka_consumer.py
==================
Consumes retail-product records from a Kafka topic and performs
real-time inference with the trained Hybrid CNN-ViT classifier.

Pipeline
--------
    Kafka topic
        |
        v
    JSON record  ->  dataframe row  ->  scale + encode (TabularToImage)
        |
        v
    HybridCNNViT  ->  predicted product category + confidence
        |
        v
    Anomaly check (residual / confidence threshold)
        |
        v
    Print / persist alert
"""

from __future__ import annotations

import argparse
import json
import time
from dataclasses import asdict
from pathlib import Path
from typing import Dict, List

import joblib
import numpy as np
import pandas as pd
import torch
from kafka import KafkaConsumer

from data_loader import DataConfig, RetailTabularDataset, TabularToImageEncoder
from model import HybridCNNViT, ModelConfig


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--ckpt", type=str, default="runs/cnn_vit/best.pt")
    p.add_argument("--csv", type=str, default="data/products.csv",
                   help="CSV used to fit the encoder/scaler (training data).")
    p.add_argument("--target", type=str, default="Product Category")
    p.add_argument("--bootstrap", type=str, default="localhost:9092")
    p.add_argument("--topic", type=str, default="inventory_topic")
    p.add_argument("--group", type=str, default="cnn-vit-inference")
    p.add_argument("--anomaly_threshold", type=float, default=0.45,
                   help="Max-prob below this is flagged as anomalous.")
    return p.parse_args()


# ---------------------------------------------------------------------------
def load_model(ckpt_path: str, device: torch.device) -> HybridCNNViT:
    ck = torch.load(ckpt_path, map_location=device)
    cfg = ModelConfig(**ck["model_config"])
    model = HybridCNNViT(cfg).to(device)
    model.load_state_dict(ck["model_state_dict"])
    model.eval()
    return model, ck["class_names"]


# ---------------------------------------------------------------------------
def main() -> None:
    args = parse_args()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 1) Re-build pre-processors (scaler, label encoders, image encoder)
    data_cfg = DataConfig(csv_path=args.csv, target_column=args.target)
    tab = RetailTabularDataset(data_cfg).load()
    encoder = TabularToImageEncoder(
        image_size=data_cfg.image_size,
        num_channels=data_cfg.num_channels,
    ).fit(tab.X)

    # 2) Load trained CNN-ViT model
    model, class_names = load_model(args.ckpt, device)
    print(f"Loaded model with {len(class_names)} classes: {class_names}")

    # 3) Connect to Kafka
    consumer = KafkaConsumer(
        args.topic,
        bootstrap_servers=args.bootstrap,
        auto_offset_reset="earliest",
        group_id=args.group,
        value_deserializer=lambda x: json.loads(x.decode("utf-8")),
    )
    print(f"Subscribed to '{args.topic}', awaiting messages ...")

    anomalies: List[Dict] = []
    seen, anomalous = 0, 0

    # 4) Inference loop
    for msg in consumer:
        record = msg.value
        seen += 1

        # Convert single record to numpy feature vector
        df = pd.DataFrame([record])
        for c in data_cfg.drop_columns:
            if c in df.columns:
                df = df.drop(columns=c)
        if args.target in df.columns:
            df = df.drop(columns=args.target)

        # Encode any object columns using the fitted encoders
        for col, le in tab.cat_encoders.items():
            if col in df.columns:
                vals = df[col].astype(str).values
                # Unseen category -> map to most-frequent class index 0
                df[col] = [
                    int(le.transform([v])[0]) if v in le.classes_ else 0
                    for v in vals
                ]
        x = df.values.astype(np.float32)
        x = tab.scaler.transform(x)
        img = encoder.transform(x)
        img_t = torch.from_numpy(img).float().to(device)

        with torch.no_grad():
            logits = model(img_t)
            probs = logits.softmax(-1).cpu().numpy()[0]

        pred_idx = int(np.argmax(probs))
        pred_label = class_names[pred_idx]
        confidence = float(probs[pred_idx])

        is_anomaly = confidence < args.anomaly_threshold
        if is_anomaly:
            anomalous += 1
            anomalies.append({
                "Product Name": record.get("Product Name", "<unknown>"),
                "predicted_class": pred_label,
                "confidence": round(confidence, 4),
            })

        flag = "ANOMALY" if is_anomaly else "OK"
        name = record.get("Product Name", "<unknown>")
        print(
            f"[{seen:>5}] {flag:>7}  {name[:30]:<30}  "
            f"-> {pred_label:<15}  conf={confidence:.3f}"
        )

        if seen % 100 == 0:
            rate = anomalous / seen
            print(f"Anomaly rate so far: {rate:.2%}")


if __name__ == "__main__":
    main()
