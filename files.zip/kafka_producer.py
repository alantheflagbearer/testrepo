"""
kafka_producer.py
==================
Streams new retail-product records to a Kafka topic, simulating a
production point-of-sale (POS) feed for real-time inventory analytics.

Usage
-----
    python kafka_producer.py --csv data/products.csv --rate 1.0
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import pandas as pd
from kafka import KafkaProducer


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--csv", type=str, default="data/products.csv")
    p.add_argument("--bootstrap", type=str, default="localhost:9092")
    p.add_argument("--topic", type=str, default="inventory_topic")
    p.add_argument("--rate", type=float, default=1.0,
                   help="Seconds to wait between messages.")
    p.add_argument("--limit", type=int, default=0,
                   help="Max number of messages (0 = all rows).")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    csv = Path(args.csv)
    if not csv.exists():
        raise FileNotFoundError(csv)

    df = pd.read_csv(csv)
    if args.limit > 0:
        df = df.head(args.limit)

    producer = KafkaProducer(
        bootstrap_servers=args.bootstrap,
        value_serializer=lambda x: json.dumps(x).encode("utf-8"),
        retries=3,
    )

    print(f"Streaming {len(df)} records to '{args.topic}' "
          f"every {args.rate}s ...")

    for idx, row in df.iterrows():
        msg = row.to_dict()
        producer.send(args.topic, value=msg)
        name = msg.get("Product Name", f"row-{idx}")
        print(f"[{idx + 1:>5}] sent: {name}")
        time.sleep(args.rate)

    producer.flush()
    producer.close()
    print("Done.")


if __name__ == "__main__":
    main()
