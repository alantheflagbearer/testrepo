"""
train.py
==========
End-to-end training, validation and evaluation pipeline for the
Hybrid CNN-Vision-Transformer retail classifier.

Features
--------
* Mixed-precision training (torch.cuda.amp)
* Cosine-annealing learning-rate schedule with linear warm-up
* Label smoothing + class-weighted cross-entropy
* Early stopping (patience-based) + best-checkpoint saving
* Per-epoch logging to console and JSON
* Final evaluation: confusion matrix, ROC-AUC (macro/OvR),
  precision/recall/F1, classification report
* TensorBoard support (optional)

Usage
-----
    $ python train.py --csv data/products.csv --epochs 50

Author: Khadija Elkattany
"""

from __future__ import annotations

import os
import time
import json
import argparse
from pathlib import Path
from dataclasses import asdict
from typing import Tuple, Dict, List

import numpy as np
import torch
import torch.nn as nn
from torch.amp import autocast, GradScaler
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    roc_auc_score,
    f1_score,
    precision_score,
    recall_score,
    accuracy_score,
)

from data_loader import DataConfig, build_dataloaders, seed_everything
from model import ModelConfig, HybridCNNViT, build_model


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser("Hybrid CNN-ViT Trainer")
    p.add_argument("--csv", type=str, default="data/products.csv")
    p.add_argument("--target", type=str, default="Product Category")
    p.add_argument("--image_size", type=int, default=32)
    p.add_argument("--batch_size", type=int, default=64)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--epochs", type=int, default=50)
    p.add_argument("--lr", type=float, default=3e-4)
    p.add_argument("--weight_decay", type=float, default=5e-4)
    p.add_argument("--warmup_epochs", type=int, default=3)
    p.add_argument("--label_smoothing", type=float, default=0.1)
    p.add_argument("--patience", type=int, default=10)
    p.add_argument("--output_dir", type=str, default="runs/cnn_vit")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--no_amp", action="store_true",
                   help="Disable automatic mixed precision")
    return p.parse_args()


# ---------------------------------------------------------------------------
# LR scheduler with warm-up + cosine decay
# ---------------------------------------------------------------------------
def cosine_warmup_lr(
    step: int,
    total_steps: int,
    warmup_steps: int,
    base_lr: float,
    min_lr: float = 1e-6,
) -> float:
    if step < warmup_steps:
        return base_lr * (step + 1) / max(1, warmup_steps)
    progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
    return min_lr + 0.5 * (base_lr - min_lr) * (1 + np.cos(np.pi * progress))


# ---------------------------------------------------------------------------
# Single epoch loops
# ---------------------------------------------------------------------------
def train_one_epoch(
    model: nn.Module,
    loader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    scaler: GradScaler,
    device: torch.device,
    epoch: int,
    total_epochs: int,
    base_lr: float,
    warmup_steps: int,
    total_steps: int,
    global_step: int,
    use_amp: bool,
) -> Tuple[float, float, int]:
    model.train()
    running_loss, running_acc, n = 0.0, 0.0, 0
    for xb, yb in loader:
        xb = xb.to(device, non_blocking=True)
        yb = yb.to(device, non_blocking=True)

        # LR schedule
        lr = cosine_warmup_lr(
            global_step, total_steps, warmup_steps, base_lr
        )
        for pg in optimizer.param_groups:
            pg["lr"] = lr

        optimizer.zero_grad(set_to_none=True)
        with autocast(device_type="cuda", enabled=use_amp):
            logits = model(xb)
            loss = criterion(logits, yb)

        scaler.scale(loss).backward()
        scaler.unscale_(optimizer)
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        scaler.step(optimizer)
        scaler.update()

        bs = xb.size(0)
        running_loss += loss.item() * bs
        running_acc += (logits.argmax(1) == yb).float().sum().item()
        n += bs
        global_step += 1

    return running_loss / n, running_acc / n, global_step


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader,
    criterion: nn.Module,
    device: torch.device,
) -> Tuple[float, float, np.ndarray, np.ndarray, np.ndarray]:
    model.eval()
    all_probs, all_preds, all_labels = [], [], []
    running_loss, n = 0.0, 0
    for xb, yb in loader:
        xb = xb.to(device, non_blocking=True)
        yb = yb.to(device, non_blocking=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        probs = logits.softmax(dim=-1)
        running_loss += loss.item() * xb.size(0)
        n += xb.size(0)
        all_probs.append(probs.cpu().numpy())
        all_preds.append(logits.argmax(1).cpu().numpy())
        all_labels.append(yb.cpu().numpy())

    probs = np.concatenate(all_probs)
    preds = np.concatenate(all_preds)
    labels = np.concatenate(all_labels)
    acc = (preds == labels).mean()
    return running_loss / n, float(acc), probs, preds, labels


# ---------------------------------------------------------------------------
# Compute final metrics
# ---------------------------------------------------------------------------
def final_metrics(
    labels: np.ndarray,
    preds: np.ndarray,
    probs: np.ndarray,
    class_names: List[str],
) -> Dict:
    report = classification_report(
        labels, preds, target_names=class_names, output_dict=True, zero_division=0
    )
    cm = confusion_matrix(labels, preds).tolist()

    # One-vs-rest macro AUC
    n_classes = probs.shape[1]
    try:
        if n_classes == 2:
            auc = float(roc_auc_score(labels, probs[:, 1]))
        else:
            auc = float(roc_auc_score(
                labels, probs, multi_class="ovr", average="macro"
            ))
    except ValueError:
        auc = float("nan")

    return {
        "accuracy": float(accuracy_score(labels, preds)),
        "macro_f1": float(f1_score(labels, preds, average="macro", zero_division=0)),
        "macro_precision": float(precision_score(labels, preds, average="macro", zero_division=0)),
        "macro_recall": float(recall_score(labels, preds, average="macro", zero_division=0)),
        "macro_roc_auc": auc,
        "confusion_matrix": cm,
        "per_class_report": report,
    }


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main() -> None:
    args = parse_args()
    seed_everything(args.seed)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ---- Data ----------------------------------------------------------
    data_cfg = DataConfig(
        csv_path=args.csv,
        image_size=args.image_size,
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        target_column=args.target,
        seed=args.seed,
    )
    train_loader, val_loader, test_loader, tab, encoder = build_dataloaders(data_cfg)

    print(f"  Classes      : {tab.num_classes}")
    print(f"  Class names  : {tab.class_names}")
    print(f"  Features     : {tab.num_features}")
    print(f"  Train batches: {len(train_loader)}")
    print(f"  Val batches  : {len(val_loader)}")
    print(f"  Test batches : {len(test_loader)}")

    # ---- Model ---------------------------------------------------------
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(num_classes=tab.num_classes, image_size=args.image_size).to(device)
    total, trainable = model.parameter_count()
    print(f"  Total params : {total:,}")
    print(f"  Trainable    : {trainable:,}")

    # ---- Loss / Optim --------------------------------------------------
    class_counts = np.bincount(np.array([y for _, y in train_loader.dataset]))
    weights = 1.0 / np.maximum(class_counts, 1)
    weights = weights / weights.sum() * tab.num_classes
    weights_t = torch.tensor(weights, dtype=torch.float32, device=device)
    criterion = nn.CrossEntropyLoss(
        weight=weights_t, label_smoothing=args.label_smoothing
    )
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=args.lr, weight_decay=args.weight_decay
    )
    use_amp = (not args.no_amp) and torch.cuda.is_available()
    scaler = GradScaler(enabled=use_amp)

    # ---- Schedule ------------------------------------------------------
    steps_per_epoch = len(train_loader)
    total_steps = steps_per_epoch * args.epochs
    warmup_steps = steps_per_epoch * args.warmup_epochs

    # ---- Loop ----------------------------------------------------------
    best_val_acc = 0.0
    patience_left = args.patience
    history: List[Dict] = []
    global_step = 0
    ckpt_path = output_dir / "best.pt"

    for epoch in range(1, args.epochs + 1):
        t0 = time.time()
        train_loss, train_acc, global_step = train_one_epoch(
            model, train_loader, criterion, optimizer, scaler,
            device, epoch, args.epochs,
            args.lr, warmup_steps, total_steps, global_step, use_amp,
        )
        val_loss, val_acc, *_ = evaluate(model, val_loader, criterion, device)
        elapsed = time.time() - t0

        log = {
            "epoch": epoch,
            "train_loss": round(train_loss, 4),
            "train_acc": round(train_acc, 4),
            "val_loss": round(val_loss, 4),
            "val_acc": round(val_acc, 4),
            "lr": optimizer.param_groups[0]["lr"],
            "time_sec": round(elapsed, 1),
        }
        history.append(log)
        print(
            f"Epoch {epoch:03d}/{args.epochs:03d} | "
            f"train_loss={train_loss:.4f}  train_acc={train_acc:.4f} | "
            f"val_loss={val_loss:.4f}    val_acc={val_acc:.4f} | "
            f"lr={log['lr']:.2e}   t={elapsed:.1f}s"
        )

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            patience_left = args.patience
            torch.save({
                "model_state_dict": model.state_dict(),
                "model_config": asdict(model.cfg),
                "class_names": tab.class_names,
                "best_val_acc": best_val_acc,
                "epoch": epoch,
            }, ckpt_path)
        else:
            patience_left -= 1
            if patience_left <= 0:
                print(f"Early stopping at epoch {epoch} (no val improvement).")
                break

    # ---- Save history --------------------------------------------------
    with open(output_dir / "history.json", "w") as f:
        json.dump(history, f, indent=2)

    # ---- Test ---------------------------------------------------------
    print("Loading best checkpoint for test evaluation ...")
    ck = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(ck["model_state_dict"])
    test_loss, test_acc, probs, preds, labels = evaluate(
        model, test_loader, criterion, device
    )
    metrics = final_metrics(labels, preds, probs, tab.class_names)
    metrics["test_loss"] = float(test_loss)
    metrics["test_acc"] = float(test_acc)
    metrics["best_val_acc"] = float(best_val_acc)

    with open(output_dir / "test_metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print("===== TEST RESULTS =====")
    print(f"  Test accuracy    : {metrics['accuracy']:.4f}")
    print(f"  Macro F1         : {metrics['macro_f1']:.4f}")
    print(f"  Macro Precision  : {metrics['macro_precision']:.4f}")
    print(f"  Macro Recall     : {metrics['macro_recall']:.4f}")
    print(f"  Macro ROC-AUC    : {metrics['macro_roc_auc']:.4f}")
    print(f"  Saved to         : {output_dir}")


if __name__ == "__main__":
    main()
