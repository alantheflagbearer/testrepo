"""
tabular_baselines.py
=====================
Trains classical tabular baselines (XGBoost and Random Forest) on the
same retail dataset for direct comparison with the Hybrid CNN-ViT.

Outputs metrics to runs/baselines/<model>.json so they can be loaded by
the thesis reporting scripts and the Streamlit dashboard.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, classification_report,
    confusion_matrix, f1_score, precision_score,
    recall_score, roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from xgboost import XGBClassifier


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", type=str, default="data/products.csv")
    p.add_argument("--target", type=str, default="Product Category")
    p.add_argument("--output_dir", type=str, default="runs/baselines")
    p.add_argument("--seed", type=int, default=42)
    return p.parse_args()


DROP_COLS = (
    "Product ID", "Product Name", "Product Description", "SKU",
    "Product Tags", "Product Dimensions", "Manufacturing Date",
    "Expiration Date", "Color/Size Variations",
)


def load_clean(csv: str, target: str):
    df = pd.read_csv(csv).dropna()
    for c in DROP_COLS:
        if c in df.columns:
            df = df.drop(columns=c)
    y_raw = df[target].astype(str).values
    df = df.drop(columns=target)
    encoders = {}
    for col in df.select_dtypes(include="object").columns:
        le = LabelEncoder()
        df[col] = le.fit_transform(df[col].astype(str))
        encoders[col] = le
    le_y = LabelEncoder()
    y = le_y.fit_transform(y_raw)
    return df.values.astype(np.float32), y, list(le_y.classes_), encoders, le_y


def evaluate(y_true, y_pred, y_prob, names):
    auc = float("nan")
    try:
        if y_prob.shape[1] == 2:
            auc = float(roc_auc_score(y_true, y_prob[:, 1]))
        else:
            auc = float(roc_auc_score(y_true, y_prob, multi_class="ovr",
                                      average="macro"))
    except Exception:
        pass
    return {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, average="macro",
                                   zero_division=0)),
        "macro_precision": float(precision_score(y_true, y_pred, average="macro",
                                                 zero_division=0)),
        "macro_recall": float(recall_score(y_true, y_pred, average="macro",
                                           zero_division=0)),
        "macro_roc_auc": auc,
        "confusion_matrix": confusion_matrix(y_true, y_pred).tolist(),
        "per_class_report": classification_report(
            y_true, y_pred, target_names=names, output_dict=True,
            zero_division=0,
        ),
    }


def main():
    args = parse_args()
    out = Path(args.output_dir)
    out.mkdir(parents=True, exist_ok=True)

    X, y, names, *_ = load_clean(args.csv, args.target)
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=args.seed,
    )

    # XGBoost ---------------------------------------------------------
    xgb = XGBClassifier(
        n_estimators=400, max_depth=6, learning_rate=0.05,
        subsample=0.9, colsample_bytree=0.9,
        objective="multi:softprob",
        eval_metric="mlogloss", random_state=args.seed,
        n_jobs=-1,
    )
    xgb.fit(X_tr, y_tr)
    yp_x = xgb.predict(X_te)
    yp_xp = xgb.predict_proba(X_te)
    metrics_xgb = evaluate(y_te, yp_x, yp_xp, names)
    with open(out / "xgboost.json", "w") as f:
        json.dump(metrics_xgb, f, indent=2)
    joblib.dump(xgb, out / "xgboost.pkl")

    # Random Forest ---------------------------------------------------
    rf = RandomForestClassifier(
        n_estimators=500, max_depth=None, n_jobs=-1,
        random_state=args.seed,
    )
    rf.fit(X_tr, y_tr)
    yp_r = rf.predict(X_te)
    yp_rp = rf.predict_proba(X_te)
    metrics_rf = evaluate(y_te, yp_r, yp_rp, names)
    with open(out / "random_forest.json", "w") as f:
        json.dump(metrics_rf, f, indent=2)
    joblib.dump(rf, out / "random_forest.pkl")

    print(f"XGBoost  acc={metrics_xgb['accuracy']:.4f}  "
          f"f1={metrics_xgb['macro_f1']:.4f}")
    print(f"RandomFr acc={metrics_rf['accuracy']:.4f}  "
          f"f1={metrics_rf['macro_f1']:.4f}")


if __name__ == "__main__":
    main()
